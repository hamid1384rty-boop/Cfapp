package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CloudflarePortCatalog
import com.example.data.model.ProxyConfig
import com.example.data.model.ProxyProtocol
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigsScreen(viewModel: MainViewModel) {
    val configs by viewModel.configs.collectAsState()
    val selectedId by viewModel.selectedConfigId.collectAsState()
    val isRefreshing by viewModel.isRefreshingSubs.collectAsState()
    val isTesting by viewModel.isTestingConfigs.collectAsState()
    val filterQuery by viewModel.configFilter.collectAsState()

    var showApplyCleanIpDialog by remember { mutableStateOf(false) }

    val filteredConfigs = remember(configs, filterQuery) {
        if (filterQuery.isBlank()) configs
        else configs.filter {
            it.name.contains(filterQuery, ignoreCase = true) ||
            it.protocol.name.contains(filterQuery, ignoreCase = true) ||
            it.server.contains(filterQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Top Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "کانفیگ‌ها",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${configs.size} کانفیگ موجود (رمزنگاری شده و غیرقابل کپی)",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                // Refresh subs button
                IconButton(
                    onClick = { viewModel.refreshAllSubsFromWorker() },
                    enabled = !isRefreshing,
                    modifier = Modifier.testTag("refresh_subs_button")
                ) {
                    if (isRefreshing) {
                        CircularProgressIndicator(
                            color = NeonBlue,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "به‌روزرسانی سابسکریپشن‌ها",
                            tint = NeonBlue
                        )
                    }
                }

                // Sort button
                IconButton(
                    onClick = { viewModel.sortConfigsBySpeed() },
                    modifier = Modifier.testTag("sort_configs_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Sort,
                        contentDescription = "مرتب‌سازی بر اساس سرعت",
                        tint = TextPrimary
                    )
                }

                // Apply Clean IP Dialog Trigger
                IconButton(
                    onClick = { showApplyCleanIpDialog = true },
                    modifier = Modifier.testTag("open_apply_clean_ip_dialog_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterCenterFocus,
                        contentDescription = "اعمال آی‌پی تمیز با پورت انتخابی",
                        tint = NeonGreen
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Field
        OutlinedTextField(
            value = filterQuery,
            onValueChange = { viewModel.setConfigFilter(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("configs_search_field"),
            placeholder = { Text("جستجو در کانفیگ‌ها...", color = TextMuted, fontSize = 13.sp) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = TextMuted
                )
            },
            trailingIcon = {
                if (filterQuery.isNotBlank()) {
                    IconButton(onClick = { viewModel.setConfigFilter("") }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "پاک کردن",
                            tint = TextMuted
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CyberCard,
                unfocusedContainerColor = CyberCard,
                focusedBorderColor = NeonBlue,
                unfocusedBorderColor = CyberBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Action Banner: Test Real Ping for All Configs
        Surface(
            color = CyberCardHover,
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = !isTesting) { viewModel.testAllConfigs() }
                .testTag("test_all_real_ping_button")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            color = NeonYellow,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = NeonYellow,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = if (isTesting) "در حال تست پینگ واقعی تمام کانفیگ‌ها..." else "تست پینگ واقعی تمام کانفیگ‌ها (v2rayNG)",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = "شروع تست",
                    color = NeonYellow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Configs List
        if (filteredConfigs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "هیچ کانفیگی یافت نشد",
                    color = TextMuted,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("configs_list"),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredConfigs, key = { it.id }) { config ->
                    ConfigItemCard(
                        config = config,
                        isSelected = config.id == selectedId,
                        onSelect = { viewModel.selectConfig(config) },
                        onTestPing = { viewModel.testSingleConfig(config) }
                    )
                }
            }
        }
    }

    // Apply Clean IP Dialog with Port Selection
    if (showApplyCleanIpDialog) {
        ApplyCleanIpDialog(
            onDismiss = { showApplyCleanIpDialog = false },
            onApply = { ports, useRandom ->
                viewModel.applyCleanIpsToConfigs(ports, useRandom)
                showApplyCleanIpDialog = false
            }
        )
    }
}

/**
 * Config card strictly without any copy button or copy action.
 * Shows name, protocol, real ping ms, and clean IP badge.
 */
@Composable
private fun ConfigItemCard(
    config: ProxyConfig,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onTestPing: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("config_card_${config.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) CyberCardHover else CyberCard
        ),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) NeonBlue else CyberBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Radio indicator & Details
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                RadioButton(
                    selected = isSelected,
                    onClick = onSelect,
                    colors = RadioButtonDefaults.colors(
                        selectedColor = NeonBlue,
                        unselectedColor = TextMuted
                    ),
                    modifier = Modifier.size(20.dp)
                )

                Column {
                    Text(
                        text = config.name,
                        color = if (isSelected) NeonBlue else TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Protocol Badge
                        Surface(
                            color = when (config.protocol) {
                                ProxyProtocol.VLESS -> NeonBlue.copy(alpha = 0.15f)
                                ProxyProtocol.VMESS -> NeonGreen.copy(alpha = 0.15f)
                                ProxyProtocol.TROJAN -> NeonYellow.copy(alpha = 0.15f)
                                else -> CyberBorder
                            },
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = config.protocol.name,
                                color = when (config.protocol) {
                                    ProxyProtocol.VLESS -> NeonBlue
                                    ProxyProtocol.VMESS -> NeonGreen
                                    ProxyProtocol.TROJAN -> NeonYellow
                                    else -> TextMuted
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }

                        // Port Badge
                        Text(
                            text = ":${config.port}",
                            color = TextMuted,
                            fontSize = 11.sp
                        )

                        // Clean IP indicator
                        if (config.isCleanIpApplied) {
                            Text(
                                text = "• تمیز (${config.cleanIpUsed})",
                                color = NeonGreen,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Real Ping badge & Ping button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Ping Display
                val ping = config.pingMs
                if (ping != null) {
                    if (ping > 0) {
                        Surface(
                            color = if (ping < 200) NeonGreen.copy(alpha = 0.15f)
                            else if (ping < 450) NeonYellow.copy(alpha = 0.15f)
                            else NeonRed.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "${ping}ms",
                                color = if (ping < 200) NeonGreen else if (ping < 450) NeonYellow else NeonRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    } else {
                        Surface(
                            color = NeonRed.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "تایم‌اوت",
                                color = NeonRed,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Test Single Ping Button
                IconButton(
                    onClick = onTestPing,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("test_ping_button_${config.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.NetworkCheck,
                        contentDescription = "تست پینگ",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ApplyCleanIpDialog(
    onDismiss: () -> Unit,
    onApply: (ports: List<Int>, useRandom: Boolean) -> Unit
) {
    var useTls by remember { mutableStateOf(true) }
    val tlsPicks = remember { mutableStateListOf<Int>() }
    val plainPicks = remember { mutableStateListOf<Int>() }
    var useRandom by remember { mutableStateOf(false) }

    val maxPicks = 5
    val picks = if (useTls) tlsPicks else plainPicks
    val portsForMode = CloudflarePortCatalog.ALL_PORTS.filter { it.isTls == useTls }.map { it.port }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "اعمال آی‌پی سفید به کانفیگ‌ها",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "آی‌پی‌های کلودفلر سالم بر روی تمام کانفیگ‌ها ست می‌شوند در حالی که SNI و دامین اصلی حفظ می‌گردد.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )

                Text(
                    text = "نوع پورت:",
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = useTls,
                        onClick = { useTls = true },
                        label = { Text("با TLS", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = !useTls,
                        onClick = { useTls = false },
                        label = { Text("بدون TLS", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Text(
                    text = "پورت‌ها (حداکثر ۵ تا، ${picks.size}/$maxPicks انتخاب شده):",
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )

                portsForMode.chunked(3).forEach { rowPorts ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        rowPorts.forEach { p ->
                            val selected = p in picks
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    if (selected) picks.remove(p)
                                    else if (picks.size < maxPicks) picks.add(p)
                                },
                                label = { Text("$p", fontSize = 12.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { useRandom = !useRandom },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "توزیع تصادفی بین نودها",
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = useRandom,
                        onCheckedChange = { useRandom = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonGreen)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onApply(picks.toList(), useRandom) },
                enabled = picks.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = CyberBg)
            ) {
                Text("اعمال به همه", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف", color = TextMuted)
            }
        },
        containerColor = CyberCard,
        shape = RoundedCornerShape(16.dp)
    )
}
