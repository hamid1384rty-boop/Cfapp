# Xray-core (VLESS-only custom build)

Removed (source deleted, no longer compiled/registered):
- proxy: vmess, trojan, shadowsocks, shadowsocks_2022, wireguard, hysteria, masque, tun
- transport: masque, hysteria (top-level only)
- conf builders for the above; config keys "vmess/trojan/shadowsocks/wireguard/hysteria/masque/tun" now unknown

Kept:
- VLESS in/out (+ Vision, Reality, encryption, mux, xudp, reverse)
- All VLESS-capable transports: tcp(raw), ws, grpc, httpupgrade, xhttp/splithttp, kcp, xdrive; security: tls, reality; finalmask
- Utility protocols: freedom, blackhole, dns, dokodemo-door, loopback, socks, http (needed for local client inbound / routing)
- transport/internet/hysteria/congestion (bbr/brutal) - required by splithttp/xdrive/xdns

Tests that depended on removed protocols were moved to _removed_tests/ (ignored by Go).

NOT compiled/tested here (no Go toolchain in sandbox). Run:
  go mod tidy && go build -trimpath -ldflags "-s -w" -o xray ./main
