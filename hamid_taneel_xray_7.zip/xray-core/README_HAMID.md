Xray-core VLESS-only custom build (see CUSTOM_CHANGES.md) + `proxy/tun` kept for the Android app
+ `libxray/` — a small gomobile wrapper used by the Android app
(Start/Stop/MeasureDelay/traffic counters). Build: `../build_xray.sh`.
