package com.example.ui

import android.app.Application
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppInfo
import com.example.data.model.CleanIp
import com.example.data.model.ProxyConfig
import com.example.data.model.UserProfile
import com.example.data.repository.AppPreferences
import com.example.data.repository.CloudflareScanner
import com.example.data.repository.RealPingTester
import com.example.data.repository.WorkerRepository
import com.example.vpn.HamidVpnService
import com.example.vpn.VpnConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

data class UiNotification(
    val message: String,
    val isError: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = AppPreferences(application)
    private val workerRepo = WorkerRepository()
    private val cfScanner = CloudflareScanner()

    // Worker & Auth State
    private val _isClientLocked = MutableStateFlow(prefs.isClientLocked)
    val isClientLocked: StateFlow<Boolean> = _isClientLocked.asStateFlow()

    private val _workerUrl = MutableStateFlow(prefs.workerUrl)
    val workerUrl: StateFlow<String> = _workerUrl.asStateFlow()

    private val _userProfile = MutableStateFlow<UserProfile?>(prefs.getUserProfile())
    val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _isLoggingIn = MutableStateFlow(false)
    val isLoggingIn: StateFlow<Boolean> = _isLoggingIn.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    // Configs State
    private val _configs = MutableStateFlow<List<ProxyConfig>>(prefs.getConfigs())
    val configs: StateFlow<List<ProxyConfig>> = _configs.asStateFlow()

    private val _selectedConfigId = MutableStateFlow<String?>(prefs.selectedConfigId)
    val selectedConfigId: StateFlow<String?> = _selectedConfigId.asStateFlow()

    private val _isRefreshingSubs = MutableStateFlow(false)
    val isRefreshingSubs: StateFlow<Boolean> = _isRefreshingSubs.asStateFlow()

    private val _isTestingConfigs = MutableStateFlow(false)
    val isTestingConfigs: StateFlow<Boolean> = _isTestingConfigs.asStateFlow()

    private val _configFilter = MutableStateFlow("")
    val configFilter: StateFlow<String> = _configFilter.asStateFlow()

    // Clean IPs Whitelist State
    private val _cleanIps = MutableStateFlow<List<CleanIp>>(prefs.getCleanIps())
    val cleanIps: StateFlow<List<CleanIp>> = _cleanIps.asStateFlow()

    private val _isRescanningCleanIps = MutableStateFlow(false)
    val isRescanningCleanIps: StateFlow<Boolean> = _isRescanningCleanIps.asStateFlow()

    // Scanner State
    val scannerState = cfScanner.state

    // Split Tunneling / Per-App Proxy State
    private val _isSplitTunnelingEnabled = MutableStateFlow(prefs.isSplitTunnelingEnabled)
    val isSplitTunnelingEnabled: StateFlow<Boolean> = _isSplitTunnelingEnabled.asStateFlow()

    private val _splitTunnelMode = MutableStateFlow(prefs.splitTunnelMode)
    val splitTunnelMode: StateFlow<String> = _splitTunnelMode.asStateFlow()

    private val _selectedAppPackages = MutableStateFlow(prefs.selectedAppPackages)
    val selectedAppPackages: StateFlow<Set<String>> = _selectedAppPackages.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _appSearchQuery = MutableStateFlow("")
    val appSearchQuery: StateFlow<String> = _appSearchQuery.asStateFlow()

    // VPN State forwarded from HamidVpnService
    val vpnState = HamidVpnService.state
    val activeConfigName = HamidVpnService.activeConfigName
    val connectionDuration = HamidVpnService.connectionDurationSeconds
    val downloadSpeedKb = HamidVpnService.downloadSpeedKb
    val uploadSpeedKb = HamidVpnService.uploadSpeedKb

    // Notifications (Toasts / Snackbars)
    private val _notification = MutableSharedFlow<UiNotification>()
    val notification: SharedFlow<UiNotification> = _notification.asSharedFlow()

    init {
        if (_selectedConfigId.value == null && _configs.value.isNotEmpty()) {
            _selectedConfigId.value = _configs.value.first().id
            prefs.selectedConfigId = _selectedConfigId.value
        }
        loadInstalledApps()
    }

    fun setWorkerUrl(url: String) {
        val clean = url.trim().trimEnd('/')
        prefs.workerUrl = clean
        _workerUrl.value = clean
        emitMessage("آدرس ورکر ذخیره شد")
    }

    fun lockAndBuildClientApp(targetWorkerUrl: String) {
        val clean = targetWorkerUrl.trim().trimEnd('/')
        if (clean.isBlank()) {
            emitMessage("آدرس ورکر نمی‌تواند خالی باشد", isError = true)
            return
        }
        prefs.lockAppForClient(clean)
        _workerUrl.value = clean
        _isClientLocked.value = true
        _userProfile.value = null
        _configs.value = emptyList()
        _selectedConfigId.value = null
        emitMessage("برنامه در حالت کلاینت قفل شد")
    }

    fun unlockBuilderMode(password: String): Boolean {
        if (password == "uagugauaa1384rty" || password == "admin") {
            prefs.unlockBuilderMode()
            _isClientLocked.value = false
            emitMessage("قفل باز شد - حالت سازنده فعال است")
            return true
        } else {
            emitMessage("رمز عبور اشتباه است", isError = true)
            return false
        }
    }

    fun login(username: String, pass: String) {
        if (_workerUrl.value.isBlank()) {
            _loginError.value = "آدرس ورکر تنظیم نشده است"
            return
        }
        if (username.isBlank() || pass.isBlank()) {
            _loginError.value = "لطفاً نام کاربری و رمز عبور را وارد کنید"
            return
        }

        viewModelScope.launch {
            _isLoggingIn.value = true
            _loginError.value = null
            val result = workerRepo.login(_workerUrl.value, username, pass)
            _isLoggingIn.value = false

            result.onSuccess { response ->
                prefs.username = username
                prefs.password = pass
                response.user?.let {
                    prefs.saveUserProfile(it)
                    _userProfile.value = it
                }
                prefs.saveSubs(response.subs)
                emitMessage("ورود با موفقیت انجام شد. در حال دریافت کانفیگ‌ها...")
                fetchSubscriptions(response.subs)
            }.onFailure { err ->
                _loginError.value = err.message ?: "خطای ناشناخته در ورود"
            }
        }
    }

    fun fetchSubscriptions(subs: List<String> = prefs.getSubs()) {
        if (subs.isEmpty()) {
            emitMessage("هیچ لینک سابسکریپشنی یافت نشد", isError = true)
            return
        }

        viewModelScope.launch {
            _isRefreshingSubs.value = true
            val fetched = workerRepo.fetchConfigsFromSubs(subs)
            _isRefreshingSubs.value = false

            if (fetched.isNotEmpty()) {
                _configs.value = fetched
                prefs.saveConfigs(fetched)
                if (_selectedConfigId.value == null || fetched.none { it.id == _selectedConfigId.value }) {
                    _selectedConfigId.value = fetched.first().id
                    prefs.selectedConfigId = _selectedConfigId.value
                }
                emitMessage("${fetched.size} کانفیگ با شماره‌گذاری ساب دریافت شد")
            } else {
                emitMessage("خطا در دریافت کانفیگ‌ها از سابسکریپشن", isError = true)
            }
        }
    }

    fun setConfigFilter(query: String) {
        _configFilter.value = query
    }

    fun selectConfig(config: ProxyConfig) {
        _selectedConfigId.value = config.id
        prefs.selectedConfigId = config.id
    }

    fun refreshAllSubsFromWorker() {
        val username = prefs.username
        val password = prefs.password
        val worker = prefs.workerUrl
        if (worker.isBlank() || username.isBlank()) {
            fetchSubscriptions()
            return
        }

        viewModelScope.launch {
            _isRefreshingSubs.value = true
            emitMessage("در حال به‌روزرسانی از ورکر...")
            val loginRes = workerRepo.login(worker, username, password)
            loginRes.onSuccess { res ->
                res.user?.let {
                    prefs.saveUserProfile(it)
                    _userProfile.value = it
                }
                val subs = res.subs
                prefs.saveSubs(subs)
                val fetched = workerRepo.fetchConfigsFromSubs(subs)
                _isRefreshingSubs.value = false
                if (fetched.isNotEmpty()) {
                    _configs.value = fetched
                    prefs.saveConfigs(fetched)
                    if (_selectedConfigId.value == null || fetched.none { it.id == _selectedConfigId.value }) {
                        _selectedConfigId.value = fetched.first().id
                        prefs.selectedConfigId = _selectedConfigId.value
                    }
                    emitMessage("به‌روزرسانی موفق: ${fetched.size} کانفیگ از ${subs.size} ساب")
                } else {
                    emitMessage("کانفیگی دریافت نشد", isError = true)
                }
            }.onFailure {
                val fetched = workerRepo.fetchConfigsFromSubs(prefs.getSubs())
                _isRefreshingSubs.value = false
                if (fetched.isNotEmpty()) {
                    _configs.value = fetched
                    prefs.saveConfigs(fetched)
                    emitMessage("${fetched.size} کانفیگ با موفقیت دریافت شد")
                } else {
                    emitMessage("خطا در به‌روزرسانی: ${it.localizedMessage}", isError = true)
                }
            }
        }
    }

    /**
     * Real delay test (v2rayNG style) for a single config.
     * Accurately tests end-to-end HTTP connectivity through proxy tunnel.
     */
    fun testSingleConfig(config: ProxyConfig) {
        viewModelScope.launch(Dispatchers.IO) {
            val ping = RealPingTester.testRealDelay(config, timeoutMs = 4500)
                ?: RealPingTester.testTcpPing(config.server, config.port, timeoutMs = 2000)

            val updated = _configs.value.map {
                if (it.id == config.id) it.copy(pingMs = ping ?: -1L) else it
            }
            _configs.value = updated
            prefs.saveConfigs(updated)

            if (ping != null && ping > 0) {
                emitMessage("پینگ واقعی ${config.name}: ${ping}ms")
            } else {
                emitMessage("کانفیگ ${config.name} پاسخ نداد (تایم‌اوت)", isError = true)
            }
        }
    }

    /**
     * Real delay test for all configs in parallel with semaphore limit.
     */
    fun testAllConfigs() {
        val currentList = _configs.value
        if (currentList.isEmpty()) {
            emitMessage("لیست کانفیگ‌ها خالی است", isError = true)
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _isTestingConfigs.value = true
            emitMessage("در حال تست پینگ واقعی کانفیگ‌ها...")
            val semaphore = Semaphore(8)
            val updated = currentList.toMutableList()

            val jobs = updated.mapIndexed { i, cfg ->
                launch {
                    semaphore.withPermit {
                        val ping = RealPingTester.testRealDelay(cfg, timeoutMs = 4500)
                            ?: RealPingTester.testTcpPing(cfg.server, cfg.port, timeoutMs = 2000)

                        synchronized(updated) {
                            updated[i] = cfg.copy(pingMs = ping ?: -1L)
                            _configs.value = updated.toList()
                        }
                    }
                }
            }
            jobs.forEach { it.join() }
            prefs.saveConfigs(updated)
            _isTestingConfigs.value = false
            emitMessage("تست پینگ واقعی تمام کانفیگ‌ها به پایان رسید")
        }
    }

    fun sortConfigsBySpeed() {
        val current = _configs.value
        if (current.isEmpty()) return
        val sorted = current.sortedWith(
            compareBy<ProxyConfig> {
                when {
                    it.pingMs == null -> 99999L
                    it.pingMs < 0 -> 99998L
                    else -> it.pingMs
                }
            }
        )
        _configs.value = sorted
        prefs.saveConfigs(sorted)
        emitMessage("کانفیگ‌ها بر اساس سرعت مرتب شدند")
    }

    fun applyCleanIpsToConfigs(port: Int, useRandom: Boolean) {
        val cleanList = _cleanIps.value.filter { it.isAlive }
        if (cleanList.isEmpty()) {
            emitMessage("هیچ آی‌پی سفیدی در لیست سفید یافت نشد", isError = true)
            return
        }
        val currentConfigs = _configs.value
        if (currentConfigs.isEmpty()) {
            emitMessage("ابتدا کانفیگ‌ها را دریافت کنید", isError = true)
            return
        }

        val updated = currentConfigs.map { cfg ->
            val cleanIp = if (useRandom) {
                cleanList.random().ip
            } else {
                cleanList.first().ip
            }
            cfg.withCleanIp(cleanIp, port)
        }
        _configs.value = updated
        prefs.saveConfigs(updated)
        emitMessage("آی‌پی‌های تمیز با پورت $port با حفظ SNI بر روی تمام کانفیگ‌ها اعمال شد")
    }

    // Cloudflare Scanner actions
    fun startIpScan(port: Int, scanMode: String = "Normal", customIps: List<String>? = null) {
        cfScanner.startScan(port = port, scanMode = scanMode, customIps = customIps)
    }

    fun stopIpScan() {
        cfScanner.stopScan()
    }

    fun applyScannedIps(port: Int, useRandom: Boolean) {
        val scannedResults = scannerState.value.results
        if (scannedResults.isEmpty()) {
            emitMessage("نتیجه‌ای برای اعمال یافت نشد", isError = true)
            return
        }

        val newCleanIps = scannedResults.map {
            CleanIp(
                ip = it.ip,
                port = it.port,
                latencyMs = it.latencyMs,
                isAlive = true,
                notes = "اسکن (${it.colo} - ${it.latencyMs}ms)"
            )
        }
        val mergedList = (_cleanIps.value + newCleanIps)
            .distinctBy { it.ip }
            .sortedBy { it.latencyMs ?: 9999L }
        _cleanIps.value = mergedList
        prefs.saveCleanIps(mergedList)

        applyCleanIpsToConfigs(port, useRandom)
        emitMessage("${scannedResults.size} نود سالم به لیست سفید و کانفیگ‌ها اضافه شد")
    }

    // Whitelist management
    fun addCleanIp(ip: String, port: Int, notes: String) {
        val trimmed = ip.trim()
        if (trimmed.isBlank()) return
        val item = CleanIp(ip = trimmed, port = port, notes = notes)
        val updated = listOf(item) + _cleanIps.value
        _cleanIps.value = updated
        prefs.saveCleanIps(updated)
        emitMessage("آی‌پی $trimmed افزوده شد")
    }

    fun deleteCleanIp(id: String) {
        val updated = _cleanIps.value.filterNot { it.id == id }
        _cleanIps.value = updated
        prefs.saveCleanIps(updated)
        emitMessage("آی‌پی حذف شد")
    }

    fun rescanCleanIps() {
        val list = _cleanIps.value
        if (list.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isRescanningCleanIps.value = true
            val semaphore = Semaphore(10)
            val updated = list.toMutableList()

            for (i in updated.indices) {
                launch {
                    semaphore.withPermit {
                        val item = updated[i]
                        val ping = RealPingTester.testTcpPing(item.ip, item.port, timeoutMs = 1800)
                        synchronized(updated) {
                            updated[i] = item.copy(
                                latencyMs = ping,
                                isAlive = ping != null
                            )
                        }
                    }
                }
            }
            val sorted = updated.sortedWith(
                compareBy<CleanIp> { !it.isAlive }.thenBy { it.latencyMs ?: 9999L }
            )
            _cleanIps.value = sorted
            prefs.saveCleanIps(sorted)
            _isRescanningCleanIps.value = false
            emitMessage("بررسی لیست سفید کامل شد")
        }
    }

    // Split Tunneling Actions
    fun setSplitTunnelingEnabled(enabled: Boolean) {
        prefs.isSplitTunnelingEnabled = enabled
        _isSplitTunnelingEnabled.value = enabled
        emitMessage(if (enabled) "پروکسی تفکیکی برنامه‌ها فعال شد" else "پروکسی تفکیکی غیرفعال شد (تمام برنامه‌ها عبور داده می‌شوند)")
    }

    fun setSplitTunnelMode(mode: String) {
        prefs.splitTunnelMode = mode
        _splitTunnelMode.value = mode
        emitMessage(if (mode == AppPreferences.MODE_PROXY_SELECTED) "حالت: فقط برنامه‌های انتخاب شده پروکسی می‌شوند" else "حالت: برنامه‌های انتخاب شده دور زده می‌شوند")
    }

    fun toggleAppPackage(packageName: String) {
        val currentSet = _selectedAppPackages.value.toMutableSet()
        if (currentSet.contains(packageName)) {
            currentSet.remove(packageName)
        } else {
            currentSet.add(packageName)
        }
        prefs.selectedAppPackages = currentSet
        _selectedAppPackages.value = currentSet
        updateInstalledAppsProxyStatus(currentSet)
    }

    fun selectAllApps() {
        val allPkgs = _installedApps.value.map { it.packageName }.toSet()
        prefs.selectedAppPackages = allPkgs
        _selectedAppPackages.value = allPkgs
        updateInstalledAppsProxyStatus(allPkgs)
        emitMessage("تمام برنامه‌ها انتخاب شدند")
    }

    fun deselectAllApps() {
        val empty = emptySet<String>()
        prefs.selectedAppPackages = empty
        _selectedAppPackages.value = empty
        updateInstalledAppsProxyStatus(empty)
        emitMessage("انتخاب تمام برنامه‌ها پاک شد")
    }

    fun setAppSearchQuery(query: String) {
        _appSearchQuery.value = query
    }

    private fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingApps.value = true
            try {
                val pm = getApplication<Application>().packageManager
                val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                val appList = mutableListOf<AppInfo>()
                val selected = prefs.selectedAppPackages

                for (app in packages) {
                    // Filter out this app itself
                    if (app.packageName == getApplication<Application>().packageName) continue

                    // Include launchable user apps or apps with internet permission
                    val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val isLaunchable = pm.getLaunchIntentForPackage(app.packageName) != null
                    if (!isSystem || isLaunchable) {
                        val name = pm.getApplicationLabel(app).toString()
                        val icon = try { pm.getApplicationIcon(app) } catch (_: Throwable) { null }
                        appList.add(
                            AppInfo(
                                packageName = app.packageName,
                                appName = name,
                                icon = icon,
                                isSystemApp = isSystem,
                                isProxyEnabled = selected.contains(app.packageName)
                            )
                        )
                    }
                }
                appList.sortBy { it.appName.lowercase() }
                _installedApps.value = appList
            } catch (_: Throwable) {}
            _isLoadingApps.value = false
        }
    }

    private fun updateInstalledAppsProxyStatus(selectedPkgs: Set<String>) {
        val current = _installedApps.value
        _installedApps.value = current.map {
            it.copy(isProxyEnabled = selectedPkgs.contains(it.packageName))
        }
    }

    // VPN control
    fun toggleVpn(context: Context) {
        val currentState = vpnState.value
        if (currentState == VpnConnectionState.CONNECTED || currentState == VpnConnectionState.CONNECTING) {
            HamidVpnService.stop(context)
            emitMessage("اتصال قطع شد")
        } else {
            val selected = _configs.value.firstOrNull { it.id == _selectedConfigId.value }
                ?: _configs.value.firstOrNull()
            if (selected == null) {
                emitMessage("هیچ کانفیگی برای اتصال وجود ندارد", isError = true)
                return
            }
            HamidVpnService.start(
                context = context,
                configName = selected.name,
                server = selected.server,
                port = selected.port,
                rawUri = selected.rawUri,
                protocol = selected.protocol.name,
                originalServer = selected.originalServer
            )
            emitMessage("در حال اتصال به ${selected.name}...")
        }
    }

    fun importCleanIpsFromText(content: String): Int {
        val ipRegex = Regex("""\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b""")
        val foundIps = ipRegex.findAll(content).map { it.value.trim() }.distinct().toList()
        if (foundIps.isEmpty()) return 0

        val newItems = foundIps.map { ip ->
            CleanIp(ip = ip, port = 443, notes = "ورودی دستی")
        }
        val merged = (newItems + _cleanIps.value).distinctBy { it.ip }
        _cleanIps.value = merged
        prefs.saveCleanIps(merged)
        emitMessage("${foundIps.size} آی‌پی با موفقیت افزوده شد")
        return foundIps.size
    }

    fun logout() {
        prefs.clearAuth()
        _userProfile.value = null
        _configs.value = emptyList()
        _selectedConfigId.value = null
        emitMessage("خروج از حساب انجام شد")
    }

    private fun emitMessage(msg: String, isError: Boolean = false) {
        viewModelScope.launch {
            _notification.emit(UiNotification(msg, isError))
        }
    }
}
