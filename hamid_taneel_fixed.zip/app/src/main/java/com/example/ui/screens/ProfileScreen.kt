package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    onNavigateToBuilder: () -> Unit = {}
) {
    val userProfile by viewModel.userProfile.collectAsState()
    val isClientLocked by viewModel.isClientLocked.collectAsState()

    var showUnlockDialog by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = "حساب کاربری و اشتراک",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "اطلاعات حساب، حجم باقی‌مانده و همگام‌سازی",
            color = TextMuted,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Profile Avatar & Name Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("profile_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(CyberCardHover),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = null,
                        tint = NeonBlue,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = userProfile?.name?.ifBlank { "کاربر hamid_taneel" } ?: "کاربر hamid_taneel",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )

                if (userProfile?.expiresAt?.isNotBlank() == true) {
                    Text(
                        text = "تاریخ انقضا: ${userProfile?.expiresAt}",
                        color = if (userProfile?.isExpired == true) NeonRed else NeonGreen,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quota Usage Card
        userProfile?.let { user ->
            if (user.quotaBytes > 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberCard),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "میزان مصرف اینترنت", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(
                                text = String.format("%.1f GB از %.1f GB", user.usedGB, user.quotaGB),
                                color = NeonBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        LinearProgressIndicator(
                            progress = { (user.percentUsed / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (user.percentUsed > 85) NeonRed else NeonBlue,
                            trackColor = CyberCardHover
                        )

                        Text(
                            text = "${user.percentUsed}% مصرف شده",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        // Actions
        Button(
            onClick = { viewModel.refreshAllSubsFromWorker() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("sync_with_worker_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NeonBlue, contentColor = CyberBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(imageVector = Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("به‌روزرسانی سرورها و حجم از Cloudflare Worker", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Unlock Builder Mode Button (if locked)
        if (isClientLocked) {
            OutlinedButton(
                onClick = { showUnlockDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("unlock_builder_mode_button"),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
            ) {
                Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("تغییر تنظیمات مدیریت / خروج از حالت کاربر", fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Logout
        OutlinedButton(
            onClick = { viewModel.logout() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("logout_button"),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.5f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonRed)
        ) {
            Icon(imageVector = Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("خروج از حساب کاربری", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }

    // Unlock Builder Mode Dialog
    if (showUnlockDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockDialog = false },
            title = { Text("ورود به حالت سازنده (Builder)", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("برای ویرایش آدرس ورکر و ساخت مجدد APK، رمز عبور مدیریت را وارد کنید:", color = TextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("رمز عبور ادمین") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = viewModel.unlockBuilderMode(passwordInput)
                        if (success) {
                            showUnlockDialog = false
                            onNavigateToBuilder()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = CyberBg)
                ) {
                    Text("تایید", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnlockDialog = false }) {
                    Text("انصراف", color = TextMuted)
                }
            },
            containerColor = CyberCard
        )
    }
}
