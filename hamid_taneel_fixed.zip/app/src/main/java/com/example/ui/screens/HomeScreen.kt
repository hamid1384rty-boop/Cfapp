package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.*
import com.example.vpn.VpnConnectionState

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onRequestVpnToggle: () -> Unit,
    onNavigateToConfigs: () -> Unit,
    onNavigateToApps: () -> Unit
) {
    val vpnState by viewModel.vpnState.collectAsState()
    val activeConfigName by viewModel.activeConfigName.collectAsState()
    val configs by viewModel.configs.collectAsState()
    val selectedId by viewModel.selectedConfigId.collectAsState()
    val durationSeconds by viewModel.connectionDuration.collectAsState()
    val downloadSpeed by viewModel.downloadSpeedKb.collectAsState()
    val uploadSpeed by viewModel.uploadSpeedKb.collectAsState()
    val isSplitTunneling by viewModel.isSplitTunnelingEnabled.collectAsState()
    val selectedPackages by viewModel.selectedAppPackages.collectAsState()

    val selectedConfig = configs.firstOrNull { it.id == selectedId } ?: configs.firstOrNull()

    val isConnected = vpnState == VpnConnectionState.CONNECTED
    val isConnecting = vpnState == VpnConnectionState.CONNECTING

    // Pulsing animation for connecting / connected states
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isConnected || isConnecting) 1.06f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Bar / Title with Eagle Avatar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, NeonBlue, CircleShape)
                        .background(CyberCard),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.hamid_eagle),
                        contentDescription = "لوگوی hamid_taneel",
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }

                Column {
                    Text(
                        text = "hamid_taneel",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isConnected) "اتصال امن برقرار است" else "آماده اتصال",
                        color = if (isConnected) NeonGreen else TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            // Quick Split Tunneling status badge
            Surface(
                color = if (isSplitTunneling) CyberCardHover else CyberCard,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSplitTunneling) NeonBlue else CyberBorder),
                modifier = Modifier
                    .clickable { onNavigateToApps() }
                    .testTag("home_split_tunnel_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Apps,
                        contentDescription = null,
                        tint = if (isSplitTunneling) NeonBlue else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isSplitTunneling) "${selectedPackages.size} برنامه" else "همه برنامه‌ها",
                        color = if (isSplitTunneling) NeonBlue else TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Large Circular Connect Button with Neon Glow
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(230.dp)
                .scale(pulseScale)
        ) {
            // Glow layer
            val glowColor = when {
                isConnected -> NeonGreen.copy(alpha = 0.25f)
                isConnecting -> NeonYellow.copy(alpha = 0.25f)
                else -> NeonBlue.copy(alpha = 0.12f)
            }

            Box(
                modifier = Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .background(glowColor)
            )

            // Outer ring
            val ringBorderColor = when {
                isConnected -> NeonGreen
                isConnecting -> NeonYellow
                else -> CyberBorder
            }

            Box(
                modifier = Modifier
                    .size(190.dp)
                    .clip(CircleShape)
                    .background(CyberCard)
                    .border(2.dp, ringBorderColor, CircleShape)
            )

            // Button Inner
            val buttonBrush = when {
                isConnected -> Brush.verticalGradient(listOf(NeonGreen, NeonGreenGlow))
                isConnecting -> Brush.verticalGradient(listOf(NeonYellow, NeonOrange))
                else -> Brush.verticalGradient(listOf(NeonBlue, NeonBlueGlow))
            }

            Surface(
                modifier = Modifier
                    .size(150.dp)
                    .shadow(16.dp, CircleShape)
                    .clip(CircleShape)
                    .clickable { onRequestVpnToggle() }
                    .testTag("vpn_toggle_button"),
                color = Color.Transparent
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(buttonBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "اتصال",
                            tint = CyberBg,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when {
                                isConnected -> "متصل"
                                isConnecting -> "در حال اتصال"
                                else -> "اتصال"
                            },
                            color = CyberBg,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Connection Stats Card (Duration, Download, Upload)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("connection_stats_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Duration
                val hours = durationSeconds / 3600
                val minutes = (durationSeconds % 3600) / 60
                val seconds = durationSeconds % 60
                val durationFormatted = String.format("%02d:%02d:%02d", hours, minutes, seconds)

                StatItem(
                    icon = Icons.Default.Timer,
                    iconColor = NeonBlue,
                    label = "مدت زمان",
                    value = if (isConnected) durationFormatted else "--:--:--"
                )

                Divider(
                    modifier = Modifier
                        .height(36.dp)
                        .width(1.dp),
                    color = CyberBorder
                )

                // Download
                StatItem(
                    icon = Icons.Default.ArrowDownward,
                    iconColor = NeonGreen,
                    label = "دانلود",
                    value = if (isConnected) "$downloadSpeed KB/s" else "0 KB/s"
                )

                Divider(
                    modifier = Modifier
                        .height(36.dp)
                        .width(1.dp),
                    color = CyberBorder
                )

                // Upload
                StatItem(
                    icon = Icons.Default.ArrowUpward,
                    iconColor = NeonOrange,
                    label = "آپلود",
                    value = if (isConnected) "$uploadSpeed KB/s" else "0 KB/s"
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Config Card (Clickable to switch config)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToConfigs() }
                .testTag("selected_config_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedConfig != null) CyberBorder else NeonYellow)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(CyberCardHover),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = NeonBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = selectedConfig?.name ?: "کانفیگی انتخاب نشده",
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            maxLines = 1
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = selectedConfig?.protocol?.name ?: "VLESS",
                                color = NeonBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (selectedConfig?.isCleanIpApplied == true) {
                                Text(
                                    text = "• IP تمیز فعال",
                                    color = NeonGreen,
                                    fontSize = 11.sp
                                )
                            }
                            selectedConfig?.pingMs?.let {
                                if (it > 0) {
                                    Text(
                                        text = "• ${it}ms",
                                        color = if (it < 200) NeonGreen else if (it < 400) NeonYellow else NeonRed,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = "انتخاب کانفیگ",
                    tint = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { onNavigateToConfigs() },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("manage_configs_button"),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = NeonBlue,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("کانفیگ‌ها", fontSize = 13.sp)
            }

            OutlinedButton(
                onClick = { onNavigateToApps() },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("manage_apps_button"),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
            ) {
                Icon(
                    imageVector = Icons.Default.Apps,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("تفکیک برنامه‌ها", fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun StatItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    label: String,
    value: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            color = TextMuted,
            fontSize = 11.sp
        )
    }
}
