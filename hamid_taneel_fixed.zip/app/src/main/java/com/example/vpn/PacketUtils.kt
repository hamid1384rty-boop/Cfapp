package com.example.vpn

import java.net.InetAddress
import java.nio.ByteBuffer

/**
 * Utility functions for parsing and constructing IPv4, TCP, and UDP packets
 * with standard RFC 791, RFC 793, RFC 768, and RFC 1035 DNS packet generation,
 * as well as TLS ClientHello SNI and HTTP Host header inspection.
 */
object PacketUtils {
    const val IPV4_HEADER_MIN_LEN = 20
    const val TCP_HEADER_MIN_LEN = 20
    const val UDP_HEADER_LEN = 8

    const val PROTOCOL_ICMP = 1
    const val PROTOCOL_TCP = 6
    const val PROTOCOL_UDP = 17

    const val TCP_FLAG_FIN = 0x01
    const val TCP_FLAG_SYN = 0x02
    const val TCP_FLAG_RST = 0x04
    const val TCP_FLAG_PSH = 0x08
    const val TCP_FLAG_ACK = 0x10
    const val TCP_FLAG_URG = 0x20

    data class ParsedIpPacket(
        val version: Int,
        val ihl: Int,
        val protocol: Int,
        val totalLength: Int,
        val srcIp: String,
        val dstIp: String,
        val srcIpBytes: ByteArray,
        val dstIpBytes: ByteArray,
        val payloadOffset: Int,
        val payloadLength: Int
    )

    data class ParsedTcpPacket(
        val srcPort: Int,
        val dstPort: Int,
        val seq: Long,
        val ack: Long,
        val dataOffset: Int,
        val flags: Int,
        val window: Int,
        val payloadOffset: Int,
        val payloadLength: Int
    ) {
        val isSyn: Boolean get() = (flags and TCP_FLAG_SYN) != 0
        val isAck: Boolean get() = (flags and TCP_FLAG_ACK) != 0
        val isFin: Boolean get() = (flags and TCP_FLAG_FIN) != 0
        val isRst: Boolean get() = (flags and TCP_FLAG_RST) != 0
        val isPsh: Boolean get() = (flags and TCP_FLAG_PSH) != 0
    }

    data class ParsedUdpPacket(
        val srcPort: Int,
        val dstPort: Int,
        val length: Int,
        val payloadOffset: Int,
        val payloadLength: Int
    )

    fun parseIp(data: ByteArray, length: Int): ParsedIpPacket? {
        if (length < IPV4_HEADER_MIN_LEN) return null
        val version = (data[0].toInt() shr 4) and 0x0F
        if (version != 4) return null
        val ihl = (data[0].toInt() and 0x0F) * 4
        if (length < ihl) return null
        val totalLength = ((data[2].toInt() and 0xFF) shl 8) or (data[3].toInt() and 0xFF)
        val validLength = Math.min(length, totalLength)
        val protocol = data[9].toInt() and 0xFF
        val srcIpBytes = data.copyOfRange(12, 16)
        val dstIpBytes = data.copyOfRange(16, 20)
        val srcIp = "${srcIpBytes[0].toInt() and 0xFF}.${srcIpBytes[1].toInt() and 0xFF}.${srcIpBytes[2].toInt() and 0xFF}.${srcIpBytes[3].toInt() and 0xFF}"
        val dstIp = "${dstIpBytes[0].toInt() and 0xFF}.${dstIpBytes[1].toInt() and 0xFF}.${dstIpBytes[2].toInt() and 0xFF}.${dstIpBytes[3].toInt() and 0xFF}"
        val payloadOffset = ihl
        val payloadLength = Math.max(0, validLength - ihl)

        return ParsedIpPacket(
            version = version,
            ihl = ihl,
            protocol = protocol,
            totalLength = validLength,
            srcIp = srcIp,
            dstIp = dstIp,
            srcIpBytes = srcIpBytes,
            dstIpBytes = dstIpBytes,
            payloadOffset = payloadOffset,
            payloadLength = payloadLength
        )
    }

    fun parseTcp(data: ByteArray, ipPacket: ParsedIpPacket): ParsedTcpPacket? {
        if (ipPacket.protocol != PROTOCOL_TCP) return null
        val offset = ipPacket.payloadOffset
        val len = ipPacket.payloadLength
        if (len < TCP_HEADER_MIN_LEN) return null

        val srcPort = ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
        val dstPort = ((data[offset + 2].toInt() and 0xFF) shl 8) or (data[offset + 3].toInt() and 0xFF)
        val seq = readUInt32(data, offset + 4)
        val ack = readUInt32(data, offset + 8)
        val dataOffset = ((data[offset + 12].toInt() and 0xF0) shr 4) * 4
        if (len < dataOffset) return null
        val flags = data[offset + 13].toInt() and 0xFF
        val window = ((data[offset + 14].toInt() and 0xFF) shl 8) or (data[offset + 15].toInt() and 0xFF)
        val payloadOffset = offset + dataOffset
        val payloadLength = Math.max(0, len - dataOffset)

        return ParsedTcpPacket(
            srcPort = srcPort,
            dstPort = dstPort,
            seq = seq,
            ack = ack,
            dataOffset = dataOffset,
            flags = flags,
            window = window,
            payloadOffset = payloadOffset,
            payloadLength = payloadLength
        )
    }

    fun parseUdp(data: ByteArray, ipPacket: ParsedIpPacket): ParsedUdpPacket? {
        if (ipPacket.protocol != PROTOCOL_UDP) return null
        val offset = ipPacket.payloadOffset
        val len = ipPacket.payloadLength
        if (len < UDP_HEADER_LEN) return null

        val srcPort = ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
        val dstPort = ((data[offset + 2].toInt() and 0xFF) shl 8) or (data[offset + 3].toInt() and 0xFF)
        val length = ((data[offset + 4].toInt() and 0xFF) shl 8) or (data[offset + 5].toInt() and 0xFF)
        val payloadOffset = offset + UDP_HEADER_LEN
        val payloadLength = Math.max(0, Math.min(len, length) - UDP_HEADER_LEN)

        return ParsedUdpPacket(
            srcPort = srcPort,
            dstPort = dstPort,
            length = length,
            payloadOffset = payloadOffset,
            payloadLength = payloadLength
        )
    }

    fun buildIpHeader(
        srcIp: ByteArray,
        dstIp: ByteArray,
        protocol: Int,
        payloadLen: Int,
        identification: Int = 0x1234
    ): ByteArray {
        val header = ByteArray(IPV4_HEADER_MIN_LEN)
        val totalLength = IPV4_HEADER_MIN_LEN + payloadLen
        header[0] = 0x45.toByte() // IPv4, IHL = 5 (20 bytes)
        header[1] = 0x00.toByte() // DSCP / ECN
        header[2] = ((totalLength shr 8) and 0xFF).toByte()
        header[3] = (totalLength and 0xFF).toByte()
        header[4] = ((identification shr 8) and 0xFF).toByte()
        header[5] = (identification and 0xFF).toByte()
        header[6] = 0x40.toByte() // Don't Fragment flag
        header[7] = 0x00.toByte()
        header[8] = 64.toByte() // TTL
        header[9] = protocol.toByte()
        header[10] = 0.toByte() // Checksum placeholder
        header[11] = 0.toByte()
        System.arraycopy(srcIp, 0, header, 12, 4)
        System.arraycopy(dstIp, 0, header, 16, 4)

        val checksum = calculateChecksum(header, 0, IPV4_HEADER_MIN_LEN)
        header[10] = ((checksum shr 8) and 0xFF).toByte()
        header[11] = (checksum and 0xFF).toByte()
        return header
    }

    fun buildUdpPacket(
        srcIp: String,
        dstIp: String,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val srcBytes = InetAddress.getByName(srcIp).address
        val dstBytes = InetAddress.getByName(dstIp).address
        val udpLen = UDP_HEADER_LEN + payload.size
        val ipHeader = buildIpHeader(srcBytes, dstBytes, PROTOCOL_UDP, udpLen)

        val udpHeader = ByteArray(UDP_HEADER_LEN)
        udpHeader[0] = ((srcPort shr 8) and 0xFF).toByte()
        udpHeader[1] = (srcPort and 0xFF).toByte()
        udpHeader[2] = ((dstPort shr 8) and 0xFF).toByte()
        udpHeader[3] = (dstPort and 0xFF).toByte()
        udpHeader[4] = ((udpLen shr 8) and 0xFF).toByte()
        udpHeader[5] = (udpLen and 0xFF).toByte()
        udpHeader[6] = 0.toByte()
        udpHeader[7] = 0.toByte()

        val full = ByteArray(ipHeader.size + udpHeader.size + payload.size)
        System.arraycopy(ipHeader, 0, full, 0, ipHeader.size)
        System.arraycopy(udpHeader, 0, full, ipHeader.size, udpHeader.size)
        System.arraycopy(payload, 0, full, ipHeader.size + udpHeader.size, payload.size)

        val udpChecksum = calculateTransportChecksum(srcBytes, dstBytes, PROTOCOL_UDP, full, ipHeader.size, udpLen)
        val cs = if (udpChecksum == 0) 0xFFFF else udpChecksum
        full[ipHeader.size + 6] = ((cs shr 8) and 0xFF).toByte()
        full[ipHeader.size + 7] = (cs and 0xFF).toByte()
        return full
    }

    fun buildTcpPacket(
        srcIp: String,
        dstIp: String,
        srcPort: Int,
        dstPort: Int,
        seq: Long,
        ack: Long,
        flags: Int,
        window: Int = 65535,
        payload: ByteArray = byteArrayOf(),
        includeMssOption: Boolean = false
    ): ByteArray {
        val srcBytes = InetAddress.getByName(srcIp).address
        val dstBytes = InetAddress.getByName(dstIp).address

        val optionsLen = if (includeMssOption) 4 else 0
        val tcpHeaderLen = TCP_HEADER_MIN_LEN + optionsLen
        val tcpLen = tcpHeaderLen + payload.size
        val ipHeader = buildIpHeader(srcBytes, dstBytes, PROTOCOL_TCP, tcpLen)

        val tcpHeader = ByteArray(tcpHeaderLen)
        tcpHeader[0] = ((srcPort shr 8) and 0xFF).toByte()
        tcpHeader[1] = (srcPort and 0xFF).toByte()
        tcpHeader[2] = ((dstPort shr 8) and 0xFF).toByte()
        tcpHeader[3] = (dstPort and 0xFF).toByte()

        // Seq (4 bytes)
        writeUInt32(tcpHeader, 4, seq)
        // Ack (4 bytes)
        writeUInt32(tcpHeader, 8, ack)

        val dataOffsetWords = tcpHeaderLen / 4
        tcpHeader[12] = ((dataOffsetWords shl 4) and 0xF0).toByte()
        tcpHeader[13] = flags.toByte()
        tcpHeader[14] = ((window shr 8) and 0xFF).toByte()
        tcpHeader[15] = (window and 0xFF).toByte()
        tcpHeader[16] = 0.toByte()
        tcpHeader[17] = 0.toByte()
        tcpHeader[18] = 0.toByte()
        tcpHeader[19] = 0.toByte()

        if (includeMssOption) {
            tcpHeader[20] = 0x02.toByte() // MSS Kind
            tcpHeader[21] = 0x04.toByte() // Length
            tcpHeader[22] = 0x05.toByte() // 1400 = 0x0578
            tcpHeader[23] = 0x78.toByte()
        }

        val full = ByteArray(ipHeader.size + tcpHeader.size + payload.size)
        System.arraycopy(ipHeader, 0, full, 0, ipHeader.size)
        System.arraycopy(tcpHeader, 0, full, ipHeader.size, tcpHeader.size)
        if (payload.isNotEmpty()) {
            System.arraycopy(payload, 0, full, ipHeader.size + tcpHeader.size, payload.size)
        }

        val tcpChecksum = calculateTransportChecksum(srcBytes, dstBytes, PROTOCOL_TCP, full, ipHeader.size, tcpLen)
        full[ipHeader.size + 16] = ((tcpChecksum shr 8) and 0xFF).toByte()
        full[ipHeader.size + 17] = (tcpChecksum and 0xFF).toByte()
        return full
    }

    private fun calculateChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i < end - 1) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (i < end) {
            sum += ((data[i].toInt() and 0xFF) shl 8)
        }
        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun calculateTransportChecksum(
        srcIp: ByteArray,
        dstIp: ByteArray,
        protocol: Int,
        fullPacket: ByteArray,
        transportOffset: Int,
        transportLen: Int
    ): Int {
        var sum = 0L
        for (i in 0 until 4 step 2) {
            sum += ((srcIp[i].toInt() and 0xFF) shl 8) or (srcIp[i + 1].toInt() and 0xFF)
            sum += ((dstIp[i].toInt() and 0xFF) shl 8) or (dstIp[i + 1].toInt() and 0xFF)
        }
        sum += protocol
        sum += transportLen

        var i = transportOffset
        val end = transportOffset + transportLen
        while (i < end - 1) {
            val word = ((fullPacket[i].toInt() and 0xFF) shl 8) or (fullPacket[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (i < end) {
            sum += ((fullPacket[i].toInt() and 0xFF) shl 8)
        }
        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    fun readUInt32(data: ByteArray, offset: Int): Long {
        return ((data[offset].toLong() and 0xFF) shl 24) or
                ((data[offset + 1].toLong() and 0xFF) shl 16) or
                ((data[offset + 2].toLong() and 0xFF) shl 8) or
                (data[offset + 3].toLong() and 0xFF)
    }

    fun writeUInt32(data: ByteArray, offset: Int, value: Long) {
        data[offset] = ((value shr 24) and 0xFF).toByte()
        data[offset + 1] = ((value shr 16) and 0xFF).toByte()
        data[offset + 2] = ((value shr 8) and 0xFF).toByte()
        data[offset + 3] = (value and 0xFF).toByte()
    }

    fun extractDnsQueryDomain(dnsPayload: ByteArray): String? {
        return try {
            if (dnsPayload.size < 12) return null
            var pos = 12
            val sb = StringBuilder()
            while (pos < dnsPayload.size) {
                val len = dnsPayload[pos].toInt() and 0xFF
                pos++
                if (len == 0) break
                if (pos + len > dnsPayload.size) return null
                if (sb.isNotEmpty()) sb.append('.')
                for (j in 0 until len) {
                    sb.append(dnsPayload[pos + j].toInt().toChar())
                }
                pos += len
            }
            sb.toString().lowercase()
        } catch (_: Exception) {
            null
        }
    }

    fun extractDnsQueryType(dnsPayload: ByteArray): Int {
        return try {
            if (dnsPayload.size < 12) return 1
            var pos = 12
            while (pos < dnsPayload.size) {
                val len = dnsPayload[pos].toInt() and 0xFF
                pos++
                if (len == 0) break
                pos += len
            }
            if (pos + 2 <= dnsPayload.size) {
                ((dnsPayload[pos].toInt() and 0xFF) shl 8) or (dnsPayload[pos + 1].toInt() and 0xFF)
            } else 1
        } catch (_: Exception) {
            1
        }
    }

    /**
     * Builds an authentic RFC 1035 DNS response packet for Type A queries.
     * Returns the answer with 0ms latency directly inside the TUN.
     */
    fun buildDnsResponse(query: ByteArray, ipAddressBytes: ByteArray): ByteArray {
        val qlen = query.size
        val response = ByteArray(qlen + 16)
        // Copy original query
        System.arraycopy(query, 0, response, 0, qlen)

        // Set Response Flags: 0x8180 (Response, Opcode 0, Authoritative 0, Truncated 0, Recursion Desired 1, Recursion Available 1, No error)
        response[2] = 0x81.toByte()
        response[3] = 0x80.toByte()

        // ANCOUNT = 1 (1 Answer)
        response[6] = 0x00.toByte()
        response[7] = 0x01.toByte()

        // Answer Section:
        var offset = qlen
        // Name Pointer to offset 12 (Question Name)
        response[offset++] = 0xC0.toByte()
        response[offset++] = 0x0C.toByte()

        // Type A: 0x0001
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x01.toByte()

        // Class IN: 0x0001
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x01.toByte()

        // TTL: 60 seconds (0x0000003C)
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x3C.toByte()

        // RDLENGTH: 4 bytes
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x04.toByte()

        // RDATA: IPv4 bytes
        response[offset++] = ipAddressBytes[0]
        response[offset++] = ipAddressBytes[1]
        response[offset++] = ipAddressBytes[2]
        response[offset] = ipAddressBytes[3]

        return response
    }

    /**
     * Builds an empty DNS response (e.g. for AAAA IPv6 queries so apps fall back to IPv4 without delay).
     */
    fun buildDnsEmptyResponse(query: ByteArray): ByteArray {
        val response = query.copyOf()
        response[2] = 0x81.toByte()
        response[3] = 0x80.toByte()
        response[6] = 0x00.toByte()
        response[7] = 0x00.toByte()
        return response
    }

    /**
     * Extracts Server Name Indication (SNI) directly from TLS ClientHello packet bytes.
     * This allows 100% accurate destination host detection for HTTPS connections.
     */
    fun extractSniFromTlsClientHello(data: ByteArray): String? {
        return try {
            if (data.size < 44) return null
            // Check TLS Record Type = Handshake (0x16)
            if (data[0] != 0x16.toByte()) return null

            // Handshake Type = ClientHello (0x01)
            var pos = 5
            if (pos >= data.size || data[pos] != 0x01.toByte()) return null

            // Skip Handshake Length (3), Client Version (2), Random (32)
            pos += 1 + 3 + 2 + 32
            if (pos >= data.size) return null

            // Session ID Length
            val sessionIdLen = data[pos].toInt() and 0xFF
            pos += 1 + sessionIdLen
            if (pos + 2 >= data.size) return null

            // Cipher Suites Length
            val cipherSuitesLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2 + cipherSuitesLen
            if (pos >= data.size) return null

            // Compression Methods Length
            val compressionMethodsLen = data[pos].toInt() and 0xFF
            pos += 1 + compressionMethodsLen
            if (pos + 2 >= data.size) return null

            // Extensions Length
            val extensionsLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            pos += 2
            val extEnd = Math.min(data.size, pos + extensionsLen)

            // Loop through extensions to find SNI (Extension Type 0x0000)
            while (pos + 4 <= extEnd) {
                val extType = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                val extLen = ((data[pos + 2].toInt() and 0xFF) shl 8) or (data[pos + 3].toInt() and 0xFF)
                pos += 4

                if (extType == 0) { // SNI Extension
                    if (pos + 5 <= extEnd) {
                        // Skip ServerNameList length (2 bytes) and NameType (1 byte, 0 = host_name)
                        val nameType = data[pos + 2].toInt() and 0xFF
                        if (nameType == 0) {
                            val nameLen = ((data[pos + 3].toInt() and 0xFF) shl 8) or (data[pos + 4].toInt() and 0xFF)
                            val nameStart = pos + 5
                            if (nameStart + nameLen <= extEnd) {
                                return String(data, nameStart, nameLen, Charsets.US_ASCII).lowercase()
                            }
                        }
                    }
                }
                pos += extLen
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Extracts Host header from cleartext HTTP request (port 80).
     */
    fun extractHostFromHttpRequest(data: ByteArray): String? {
        return try {
            val text = String(data, 0, Math.min(data.size, 1024), Charsets.US_ASCII)
            val lines = text.split("\r\n")
            for (line in lines) {
                if (line.startsWith("Host:", ignoreCase = true)) {
                    val host = line.substringAfter(":").trim()
                    return host.substringBefore(":")
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    fun extractResolvedIps(dnsResponse: ByteArray): List<String> {
        val result = mutableListOf<String>()
        try {
            if (dnsResponse.size < 12) return emptyList()
            val qdCount = ((dnsResponse[4].toInt() and 0xFF) shl 8) or (dnsResponse[5].toInt() and 0xFF)
            val anCount = ((dnsResponse[6].toInt() and 0xFF) shl 8) or (dnsResponse[7].toInt() and 0xFF)
            if (anCount <= 0) return emptyList()
            var pos = 12
            for (q in 0 until qdCount) {
                while (pos < dnsResponse.size) {
                    val len = dnsResponse[pos].toInt() and 0xFF
                    pos++
                    if (len == 0) break
                    if ((len and 0xC0) == 0xC0) {
                        pos++
                        break
                    }
                    pos += len
                }
                pos += 4
            }
            for (a in 0 until anCount) {
                if (pos >= dnsResponse.size) break
                val b = dnsResponse[pos].toInt() and 0xFF
                if ((b and 0xC0) == 0xC0) {
                    pos += 2
                } else {
                    while (pos < dnsResponse.size && dnsResponse[pos].toInt() != 0) pos++
                    pos++
                }
                if (pos + 10 > dnsResponse.size) break
                val type = ((dnsResponse[pos].toInt() and 0xFF) shl 8) or (dnsResponse[pos + 1].toInt() and 0xFF)
                val rdLen = ((dnsResponse[pos + 8].toInt() and 0xFF) shl 8) or (dnsResponse[pos + 9].toInt() and 0xFF)
                pos += 10
                if (type == 1 && rdLen == 4 && pos + 4 <= dnsResponse.size) {
                    val ip = "${dnsResponse[pos].toInt() and 0xFF}.${dnsResponse[pos + 1].toInt() and 0xFF}.${dnsResponse[pos + 2].toInt() and 0xFF}.${dnsResponse[pos + 3].toInt() and 0xFF}"
                    result.add(ip)
                }
                pos += rdLen
            }
        } catch (_: Exception) {}
        return result
    }
}
