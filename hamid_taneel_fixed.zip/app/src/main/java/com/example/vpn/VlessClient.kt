package com.example.vpn

import android.net.VpnService
import com.example.data.model.ProxyConfig
import com.example.data.model.ProxyProtocol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.security.cert.X509Certificate

object VlessClient {
    private val secureRandom = SecureRandom()

    private val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        override fun checkClientTrusted(certs: Array<X509Certificate>, authType: String) {}
        override fun checkServerTrusted(certs: Array<X509Certificate>, authType: String) {}
    })

    private val sslContext: SSLContext by lazy {
        SSLContext.getInstance("TLS").apply {
            init(null, trustAllCerts, secureRandom)
        }
    }

    /**
     * Represents an open tunnel ready for bidirectional streaming without byte loss.
     */
    class TunnelConnection(
        val underlyingSocket: Socket,
        val isWebSocket: Boolean = false,
        private val isVless: Boolean = false
    ) {
        val inputStream: InputStream = underlyingSocket.inputStream
        val outputStream: OutputStream = underlyingSocket.outputStream
        private var vlessResponseHeaderStripped = false
        private var leftoverBuffer = ByteArray(0)

        fun writePayload(data: ByteArray) {
            synchronized(outputStream) {
                if (isWebSocket) {
                    writeWsBinaryFrame(outputStream, data)
                } else {
                    outputStream.write(data)
                    outputStream.flush()
                }
            }
        }

        fun readPayload(buffer: ByteArray): Int {
            if (!isWebSocket) {
                return inputStream.read(buffer)
            }

            // 1. Deliver leftover bytes from a previously buffered large WebSocket frame
            if (leftoverBuffer.isNotEmpty()) {
                val toCopy = Math.min(buffer.size, leftoverBuffer.size)
                System.arraycopy(leftoverBuffer, 0, buffer, 0, toCopy)
                leftoverBuffer = if (leftoverBuffer.size > toCopy) {
                    leftoverBuffer.copyOfRange(toCopy, leftoverBuffer.size)
                } else {
                    ByteArray(0)
                }
                return toCopy
            }

            // 2. Read next WebSocket frame from network
            var frame = readWsPayload(inputStream, outputStream) ?: return -1

            // 3. Strip 2-byte VLESS response header [0x00, addonLen] from first incoming frame
            if (isVless && !vlessResponseHeaderStripped) {
                vlessResponseHeaderStripped = true
                if (frame.size >= 2 && frame[0] == 0x00.toByte()) {
                    val addonLen = frame[1].toInt() and 0xFF
                    val headerSize = 2 + addonLen
                    if (frame.size > headerSize) {
                        frame = frame.copyOfRange(headerSize, frame.size)
                    } else {
                        // Header alone in this frame; read next frame for real payload
                        frame = readWsPayload(inputStream, outputStream) ?: return -1
                    }
                }
            }

            if (frame.isEmpty()) return 0

            val toCopy = Math.min(buffer.size, frame.size)
            System.arraycopy(frame, 0, buffer, 0, toCopy)

            // Buffer remaining bytes so no data is ever discarded!
            if (frame.size > toCopy) {
                leftoverBuffer = frame.copyOfRange(toCopy, frame.size)
            }

            return toCopy
        }

        fun close() {
            try {
                underlyingSocket.close()
            } catch (_: Throwable) {}
        }
    }

    /**
     * Connects to the remote proxy server (using clean IP or server domain),
     * performs TLS and WebSocket/VLESS handshake, and returns an open connected TunnelConnection.
     */
    suspend fun openTunnel(
        vpnService: VpnService?,
        config: ProxyConfig?,
        targetHost: String,
        targetPort: Int,
        initialPayload: ByteArray? = null,
        timeoutMs: Int = 8000
    ): TunnelConnection? = withContext(Dispatchers.IO) {
        if (config == null) {
            return@withContext openDirectTunnel(vpnService, targetHost, targetPort)
        }
        try {
            val serverAddress = config.server.trim()
            val serverPort = config.port
            val sni = if (config.isCleanIpApplied && config.originalServer.isNotBlank()) {
                config.originalServer
            } else {
                extractSniFromUri(config.rawUri) ?: config.originalServer.ifBlank { serverAddress }
            }

            // 1. Create base TCP socket and protect it from VPN routing loops
            val baseSocket = Socket()
            baseSocket.tcpNoDelay = true
            vpnService?.protect(baseSocket)
            baseSocket.connect(InetSocketAddress(serverAddress, serverPort), timeoutMs)

            val isTlsPort = serverPort in listOf(443, 8443, 2053, 2083, 2087, 2096)
            val requiresTls = isTlsPort || config.rawUri.contains("security=tls", ignoreCase = true)

            // 2. Wrap in TLS with target SNI (so Cloudflare routes cleanly)
            val activeSocket = if (requiresTls) {
                val sslSocket = sslContext.socketFactory.createSocket(
                    baseSocket,
                    sni,
                    serverPort,
                    true
                ) as SSLSocket
                sslSocket.useClientMode = true
                try {
                    val sslParams = sslSocket.sslParameters
                    sslParams.serverNames = listOf(SNIHostName(sni))
                    sslSocket.sslParameters = sslParams
                } catch (_: Throwable) {}
                sslSocket.soTimeout = timeoutMs
                sslSocket.startHandshake()
                sslSocket.soTimeout = 0 // handshake only; idle reads must not time out
                sslSocket
            } else {
                baseSocket
            }

            val transport = extractQueryParam(config.rawUri, "type")?.lowercase()
            val isWs = when (transport) {
                "ws" -> true
                null, "" -> extractPathFromUri(config.rawUri) != null
                else -> false
            }

            // 3. WebSocket Upgrade (Standard for Cloudflare Workers & Cloudflare Pages)
            if (isWs) {
                val wsPath = extractPathFromUri(config.rawUri) ?: "/"
                val hostHeader = extractHostHeader(config.rawUri) ?: sni
                val upgraded = performWebSocketHandshake(activeSocket.outputStream, activeSocket.inputStream, hostHeader, wsPath)
                if (!upgraded) {
                    activeSocket.close()
                    return@withContext null
                }
            }

            // 4. Send Protocol Header (VLESS / Trojan) + Initial Payload in First Frame
            val isVless = config.protocol == ProxyProtocol.VLESS
            when (config.protocol) {
                ProxyProtocol.VLESS -> {
                    val uuidString = extractUuidFromUri(config.rawUri)
                    val uuid = try {
                        UUID.fromString(uuidString)
                    } catch (_: Exception) {
                        UUID.randomUUID()
                    }
                    val headerBytes = buildVlessHeader(uuid, targetHost, targetPort)
                    val firstFrameBytes = if (initialPayload != null && initialPayload.isNotEmpty()) {
                        headerBytes + initialPayload
                    } else {
                        headerBytes
                    }

                    if (isWs) {
                        writeWsBinaryFrame(activeSocket.outputStream, firstFrameBytes)
                    } else {
                        activeSocket.outputStream.write(firstFrameBytes)
                        activeSocket.outputStream.flush()
                        readVlessResponse(activeSocket.inputStream)
                    }
                }
                ProxyProtocol.TROJAN -> {
                    val password = extractPasswordFromUri(config.rawUri) ?: "password"
                    val headerBytes = buildTrojanHeader(password, targetHost, targetPort)
                    val firstFrameBytes = if (initialPayload != null && initialPayload.isNotEmpty()) {
                        headerBytes + initialPayload
                    } else {
                        headerBytes
                    }

                    if (isWs) {
                        writeWsBinaryFrame(activeSocket.outputStream, firstFrameBytes)
                    } else {
                        activeSocket.outputStream.write(firstFrameBytes)
                        activeSocket.outputStream.flush()
                    }
                }
                else -> {
                    if (initialPayload != null && initialPayload.isNotEmpty()) {
                        if (isWs) {
                            writeWsBinaryFrame(activeSocket.outputStream, initialPayload)
                        } else {
                            activeSocket.outputStream.write(initialPayload)
                            activeSocket.outputStream.flush()
                        }
                    }
                }
            }

            TunnelConnection(activeSocket, isWebSocket = isWs, isVless = isVless)
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Opens a probe tunnel for Real Delay test without needing VpnService instance.
     */
    suspend fun openProbeTunnel(
        config: ProxyConfig,
        targetHost: String,
        targetPort: Int,
        timeoutMs: Int = 4500
    ): TunnelConnection? {
        return openTunnel(vpnService = null, config = config, targetHost = targetHost, targetPort = targetPort, timeoutMs = timeoutMs)
    }

    private fun openDirectTunnel(
        vpnService: VpnService?,
        targetHost: String,
        targetPort: Int
    ): TunnelConnection? {
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            vpnService?.protect(s)
            s.connect(InetSocketAddress(targetHost, targetPort), 5000)
            TunnelConnection(s, isWebSocket = false, isVless = false)
        } catch (_: Throwable) {
            null
        }
    }

    private fun performWebSocketHandshake(
        out: OutputStream,
        input: InputStream,
        hostHeader: String,
        path: String
    ): Boolean {
        return try {
            val cleanPath = if (path.startsWith("/")) path else "/$path"
            val nonce = ByteArray(16)
            secureRandom.nextBytes(nonce)
            val secKey = android.util.Base64.encodeToString(nonce, android.util.Base64.NO_WRAP)
            val req = "GET $cleanPath HTTP/1.1\r\n" +
                    "Host: $hostHeader\r\n" +
                    "Upgrade: websocket\r\n" +
                    "Connection: Upgrade\r\n" +
                    "Sec-WebSocket-Key: $secKey\r\n" +
                    "Sec-WebSocket-Version: 13\r\n\r\n"
            out.write(req.toByteArray(Charsets.US_ASCII))
            out.flush()

            // Read HTTP response headers until CRLF CRLF
            val headerBuffer = StringBuilder()
            var prev1 = 0
            var prev2 = 0
            var prev3 = 0

            while (true) {
                val b = input.read()
                if (b == -1) return false
                headerBuffer.append(b.toChar())
                if (prev3 == '\r'.code && prev2 == '\n'.code && prev1 == '\r'.code && b == '\n'.code) {
                    break
                }
                prev3 = prev2
                prev2 = prev1
                prev1 = b
                if (headerBuffer.length > 8192) return false
            }

            val headers = headerBuffer.toString()
            headers.startsWith("HTTP/1.1 101") || headers.startsWith("HTTP/1.0 101")
        } catch (_: Throwable) {
            false
        }
    }

    private fun writeWsBinaryFrame(out: OutputStream, data: ByteArray) {
        val len = data.size
        val mask = ByteArray(4)
        secureRandom.nextBytes(mask)

        val headerSize = if (len <= 125) 6 else if (len <= 65535) 8 else 14
        val header = ByteArray(headerSize)
        header[0] = 0x82.toByte() // FIN + Binary frame (Opcode 2)

        var offset = 1
        if (len <= 125) {
            header[offset++] = (0x80 or len).toByte()
        } else if (len <= 65535) {
            header[offset++] = (0x80 or 126).toByte()
            header[offset++] = ((len shr 8) and 0xFF).toByte()
            header[offset++] = (len and 0xFF).toByte()
        } else {
            header[offset++] = (0x80 or 127).toByte()
            for (i in 7 downTo 0) {
                header[offset++] = ((len.toLong() shr (i * 8)) and 0xFF).toByte()
            }
        }
        System.arraycopy(mask, 0, header, offset, 4)
        offset += 4

        val maskedPayload = ByteArray(len)
        for (i in 0 until len) {
            maskedPayload[i] = (data[i].toInt() xor mask[i % 4].toInt()).toByte()
        }

        out.write(header, 0, offset)
        out.write(maskedPayload)
        out.flush()
    }

    private fun readWsPayload(input: InputStream, output: OutputStream? = null): ByteArray? {
        while (true) {
            val b0 = input.read()
            if (b0 == -1) return null
            val b1 = input.read()
            if (b1 == -1) return null

            val opcode = b0 and 0x0F
            val isMasked = (b1 and 0x80) != 0
            var len = (b1 and 0x7F).toLong()

            if (len == 126L) {
                val b2 = input.read()
                val b3 = input.read()
                if (b2 == -1 || b3 == -1) return null
                len = (((b2 and 0xFF) shl 8) or (b3 and 0xFF)).toLong()
            } else if (len == 127L) {
                len = 0L
                for (i in 0 until 8) {
                    val b = input.read()
                    if (b == -1) return null
                    len = (len shl 8) or (b.toLong() and 0xFF)
                }
            }

            val mask = if (isMasked) {
                val m = ByteArray(4)
                readFully(input, m)
                m
            } else null

            if (len > 16 * 1024 * 1024 || len < 0) return null
            val payload = ByteArray(len.toInt())
            readFully(input, payload)

            if (mask != null) {
                for (i in payload.indices) {
                    payload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
                }
            }

            // Handle Opcode:
            when (opcode) {
                2, 0 -> {
                    // Binary or Continuation frame: return payload
                    return payload
                }
                9 -> {
                    // Ping frame: reply with Pong frame (Opcode 0x0A)
                    if (output != null) {
                        try {
                            val pongHeader = byteArrayOf(0x8A.toByte(), payload.size.toByte())
                            synchronized(output) {
                                output.write(pongHeader)
                                output.write(payload)
                                output.flush()
                            }
                        } catch (_: Throwable) {}
                    }
                }
                8 -> {
                    // Close frame
                    return null
                }
                else -> {
                    // Skip other control frames and continue reading
                }
            }
        }
    }

    private fun readFully(input: InputStream, buffer: ByteArray) {
        var read = 0
        while (read < buffer.size) {
            val r = input.read(buffer, read, buffer.size - read)
            if (r == -1) break
            read += r
        }
    }

    /**
     * Constructs valid VLESS request header.
     * Strictly differentiates between IPv4 literal vs Domain Name so that Cloudflare Workers
     * receive the Domain Name string (Type 0x02) and execute hostname connection properly.
     */
    private fun buildVlessHeader(uuid: UUID, targetHost: String, targetPort: Int): ByteArray {
        val buffer = ByteBuffer.allocate(512)
        // Protocol Version: 0
        buffer.put(0x00.toByte())
        // 16-byte UUID
        buffer.putLong(uuid.mostSignificantBits)
        buffer.putLong(uuid.leastSignificantBits)
        // Addons length: 0
        buffer.put(0x00.toByte())
        // Command: 1 (TCP)
        buffer.put(0x01.toByte())
        // Target Port: 2 bytes Big Endian
        buffer.putShort(targetPort.toShort())

        val isIpv4Literal = targetHost.matches(Regex("""^([0-9]{1,3}\.){3}[0-9]{1,3}$"""))
        val isIpv6Literal = targetHost.contains(":") && !targetHost.contains(".")

        if (isIpv4Literal) {
            val parts = targetHost.split(".")
            buffer.put(0x01.toByte()) // IPv4
            for (p in parts) {
                buffer.put(p.toInt().toByte())
            }
        } else if (isIpv6Literal) {
            try {
                val addr = InetAddress.getByName(targetHost)
                buffer.put(0x03.toByte()) // IPv6
                buffer.put(addr.address)
            } catch (_: Exception) {
                val hostBytes = targetHost.toByteArray(Charsets.UTF_8)
                buffer.put(0x02.toByte()) // Domain fallback
                buffer.put(hostBytes.size.toByte())
                buffer.put(hostBytes)
            }
        } else {
            // Domain Name (e.g. "www.youtube.com", "instagram.com") -> Type 0x02
            val hostBytes = targetHost.toByteArray(Charsets.UTF_8)
            buffer.put(0x02.toByte()) // Domain
            buffer.put(hostBytes.size.toByte())
            buffer.put(hostBytes)
        }

        val res = ByteArray(buffer.position())
        buffer.rewind()
        buffer.get(res)
        return res
    }

    private fun readVlessResponse(input: InputStream) {
        try {
            val version = input.read()
            if (version == -1) return
            val addonLen = input.read()
            if (addonLen > 0) {
                val addonBytes = ByteArray(addonLen)
                readFully(input, addonBytes)
            }
        } catch (_: Throwable) {}
    }

    private fun buildTrojanHeader(password: String, targetHost: String, targetPort: Int): ByteArray {
        val sha224 = MessageDigest.getInstance("SHA-224")
        val hashBytes = sha224.digest(password.toByteArray(Charsets.UTF_8))
        val hexHash = hashBytes.joinToString("") { "%02x".format(it) }

        val buffer = ByteBuffer.allocate(512)
        buffer.put(hexHash.toByteArray(Charsets.US_ASCII))
        buffer.put(0x0D.toByte()) // \r
        buffer.put(0x0A.toByte()) // \n
        buffer.put(0x01.toByte()) // TCP

        val isIpv4Literal = targetHost.matches(Regex("""^([0-9]{1,3}\.){3}[0-9]{1,3}$"""))
        if (isIpv4Literal) {
            val parts = targetHost.split(".")
            buffer.put(0x01.toByte()) // IPv4
            for (p in parts) {
                buffer.put(p.toInt().toByte())
            }
        } else {
            val hostBytes = targetHost.toByteArray(Charsets.UTF_8)
            buffer.put(0x02.toByte()) // Domain
            buffer.put(hostBytes.size.toByte())
            buffer.put(hostBytes)
        }

        buffer.putShort(targetPort.toShort())
        buffer.put(0x0D.toByte())
        buffer.put(0x0A.toByte())

        val res = ByteArray(buffer.position())
        buffer.rewind()
        buffer.get(res)
        return res
    }

    private fun extractUuidFromUri(rawUri: String): String {
        return rawUri.substringAfter("://").substringBefore("@")
    }

    private fun extractPasswordFromUri(rawUri: String): String? {
        return rawUri.substringAfter("://").substringBefore("@")
    }

    private fun extractSniFromUri(rawUri: String): String? {
        val query = rawUri.substringAfter("?", "").substringBefore("#")
        if (query.isNotEmpty()) {
            query.split("&").forEach { part ->
                val kv = part.split("=", limit = 2)
                if (kv.getOrNull(0) == "sni" && kv.size > 1) return kv[1]
                if (kv.getOrNull(0) == "host" && kv.size > 1) return kv[1]
            }
        }
        return null
    }

    private fun extractHostHeader(rawUri: String): String? {
        val query = rawUri.substringAfter("?", "").substringBefore("#")
        if (query.isNotEmpty()) {
            query.split("&").forEach { part ->
                val kv = part.split("=", limit = 2)
                if (kv.getOrNull(0) == "host" && kv.size > 1) return kv[1]
            }
        }
        return null
    }

    private fun extractQueryParam(rawUri: String, key: String): String? {
        val query = rawUri.substringAfter("?", "").substringBefore("#")
        for (part in query.split("&")) {
            val kv = part.split("=", limit = 2)
            if (kv.getOrNull(0) == key && kv.size > 1) return kv[1]
        }
        return null
    }

    private fun extractPathFromUri(rawUri: String): String? {
        val query = rawUri.substringAfter("?", "").substringBefore("#")
        if (query.isNotEmpty()) {
            query.split("&").forEach { part ->
                val kv = part.split("=", limit = 2)
                if (kv.getOrNull(0) == "path" && kv.size > 1) {
                    return try {
                        java.net.URLDecoder.decode(kv[1], "UTF-8")
                    } catch (_: Exception) {
                        kv[1]
                    }
                }
            }
        }
        return null
    }
}
