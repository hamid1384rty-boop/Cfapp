package com.example.data.repository

import com.example.data.model.ProxyConfig
import com.example.data.model.ProxyProtocol
import com.example.vpn.VlessClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

/**
 * Real Delay / HTTP URL ping tester modeled after v2rayNG (2dust/v2rayng).
 * Unlike simple TCP connect (which gets fake SYN-ACK responses from DPI/middleboxes in Iran),
 * this performs an end-to-end request through the proxy to an actual endpoint (generate_204 / trace)
 * and verifies that valid HTTP data is actually received.
 */
object RealPingTester {

    /**
     * Measures true end-to-end proxy latency in ms.
     * Returns the elapsed time in ms if the proxy actually completes the handshake and receives
     * a valid HTTP 200/204 response. Returns null if blocked, timed out, or handshake failed.
     */
    suspend fun testRealDelay(
        config: ProxyConfig,
        timeoutMs: Int = 4500
    ): Long? = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            // Attempt protocol probe using VlessClient
            val tunnel = VlessClient.openProbeTunnel(
                config = config,
                targetHost = "cp.cloudflare.com",
                targetPort = 80,
                timeoutMs = timeoutMs
            ) ?: return@withContext null

            try {
                // Send lightweight HTTP probe through the established tunnel
                val probeReq = "GET /generate_204 HTTP/1.1\r\n" +
                        "Host: cp.cloudflare.com\r\n" +
                        "User-Agent: v2rayNG/1.8.5\r\n" +
                        "Connection: close\r\n\r\n"

                tunnel.writePayload(probeReq.toByteArray(Charsets.US_ASCII))

                val buf = ByteArray(512)
                val read = tunnel.readPayload(buf)
                if (read > 0) {
                    val resp = String(buf, 0, read, Charsets.US_ASCII)
                    if (resp.startsWith("HTTP/1.1 204") ||
                        resp.startsWith("HTTP/1.1 200") ||
                        resp.startsWith("HTTP/1.0 204") ||
                        resp.startsWith("HTTP/1.0 200") ||
                        resp.contains("cf-ray:") ||
                        resp.contains("Cloudflare")
                    ) {
                        return@withContext (System.currentTimeMillis() - start)
                    }
                }
            } finally {
                tunnel.close()
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Fallback TCP socket ping (measures direct TCP handshake time)
     */
    suspend fun testTcpPing(host: String, port: Int, timeoutMs: Int = 2200): Long? =
        withContext(Dispatchers.IO) {
            val cleanHost = host.trim().removePrefix("[").removeSuffix("]")
            if (cleanHost.isBlank() || port <= 0 || port > 65535) return@withContext null
            val socket = Socket()
            try {
                socket.tcpNoDelay = true
                val start = System.currentTimeMillis()
                val socketAddress = InetSocketAddress(cleanHost, port)
                socket.connect(socketAddress, timeoutMs)
                val duration = System.currentTimeMillis() - start
                socket.close()
                duration
            } catch (_: Exception) {
                try { socket.close() } catch (_: Exception) {}
                null
            }
        }
}
