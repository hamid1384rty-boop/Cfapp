package com.example.data.model

import android.util.Base64
import org.json.JSONObject
import java.net.URLDecoder

enum class ProxyProtocol {
    VLESS, VMESS, TROJAN, SHADOWSOCKS, OTHER
}

data class ProxyConfig(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val originalName: String,
    val protocol: ProxyProtocol,
    val server: String,
    val port: Int,
    val originalServer: String,
    val originalPort: Int,
    val subIndex: Int,
    val rawUri: String,
    val pingMs: Long? = null,
    val isCleanIpApplied: Boolean = false,
    val cleanIpUsed: String? = null
) {
    /**
     * Replaces the server address and port with a clean Cloudflare IP and chosen port,
     * preserving the original server domain in SNI/Host so Cloudflare CDN routes it correctly.
     */
    fun withCleanIp(cleanIp: String, newPort: Int): ProxyConfig {
        val updatedRawUri = applyCleanIpToUri(rawUri, protocol, originalServer, cleanIp, newPort)
        return copy(
            server = cleanIp,
            port = newPort,
            rawUri = updatedRawUri,
            isCleanIpApplied = true,
            cleanIpUsed = cleanIp,
            pingMs = null // Reset ping so user can re-test
        )
    }

    companion object {
        fun parse(rawInput: String, subIndex: Int): ProxyConfig? {
            val raw = rawInput.trim()
            if (raw.isBlank() || raw.startsWith("//") || raw.startsWith("#")) return null
            return try {
                when {
                    raw.startsWith("vless://", ignoreCase = true) -> parseVless(raw, subIndex)
                    raw.startsWith("vmess://", ignoreCase = true) -> parseVmess(raw, subIndex)
                    raw.startsWith("trojan://", ignoreCase = true) -> parseTrojan(raw, subIndex)
                    raw.startsWith("ss://", ignoreCase = true) -> parseShadowsocks(raw, subIndex)
                    else -> null
                }
            } catch (_: Exception) {
                null
            }
        }

        private fun parseVless(raw: String, subIndex: Int): ProxyConfig? {
            val afterScheme = raw.substringAfter("://")
            val atIndex = afterScheme.indexOf('@')
            if (atIndex == -1) return null
            val afterAt = afterScheme.substring(atIndex + 1)
            val beforeQuery = afterAt.substringBefore('?').substringBefore('#')
            val server: String
            val port: Int
            if (beforeQuery.startsWith("[") && beforeQuery.contains("]")) {
                server = beforeQuery.substringBefore("]") + "]"
                port = beforeQuery.substringAfter("]:", "443").toIntOrNull() ?: 443
            } else if (beforeQuery.contains(":")) {
                val parts = beforeQuery.split(":")
                server = parts[0].trim()
                port = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 443
            } else {
                server = beforeQuery.trim()
                port = 443
            }
            if (server.isBlank()) return null
            val rawName = if (raw.contains("#")) safeDecode(raw.substringAfter("#").trim()) else "VLESS-$server"
            val suffixedName = "$rawName $subIndex"
            return ProxyConfig(
                name = suffixedName,
                originalName = rawName,
                protocol = ProxyProtocol.VLESS,
                server = server,
                port = port,
                originalServer = server,
                originalPort = port,
                subIndex = subIndex,
                rawUri = raw
            )
        }

        private fun parseTrojan(raw: String, subIndex: Int): ProxyConfig? {
            val afterScheme = raw.substringAfter("://")
            val atIndex = afterScheme.indexOf('@')
            if (atIndex == -1) return null
            val afterAt = afterScheme.substring(atIndex + 1)
            val beforeQuery = afterAt.substringBefore('?').substringBefore('#')
            val server: String
            val port: Int
            if (beforeQuery.startsWith("[") && beforeQuery.contains("]")) {
                server = beforeQuery.substringBefore("]") + "]"
                port = beforeQuery.substringAfter("]:", "443").toIntOrNull() ?: 443
            } else if (beforeQuery.contains(":")) {
                val parts = beforeQuery.split(":")
                server = parts[0].trim()
                port = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 443
            } else {
                server = beforeQuery.trim()
                port = 443
            }
            if (server.isBlank()) return null
            val rawName = if (raw.contains("#")) safeDecode(raw.substringAfter("#").trim()) else "Trojan-$server"
            val suffixedName = "$rawName $subIndex"
            return ProxyConfig(
                name = suffixedName,
                originalName = rawName,
                protocol = ProxyProtocol.TROJAN,
                server = server,
                port = port,
                originalServer = server,
                originalPort = port,
                subIndex = subIndex,
                rawUri = raw
            )
        }

        private fun parseVmess(raw: String, subIndex: Int): ProxyConfig? {
            val b64 = raw.substringAfter("vmess://").trim().replace("\\s".toRegex(), "")
            val decodedJson = decodeBase64Safe(b64) ?: return null
            val json = JSONObject(decodedJson)
            val server = json.optString("add", "").trim()
            val port = json.optInt("port", 443)
            val rawName = json.optString("ps", "VMess-$server").trim()
            if (server.isBlank()) return null
            val suffixedName = "$rawName $subIndex"
            return ProxyConfig(
                name = suffixedName,
                originalName = rawName,
                protocol = ProxyProtocol.VMESS,
                server = server,
                port = port,
                originalServer = server,
                originalPort = port,
                subIndex = subIndex,
                rawUri = raw
            )
        }

        private fun parseShadowsocks(raw: String, subIndex: Int): ProxyConfig? {
            val clean = raw.substringAfter("ss://").trim()
            val hashSplit = clean.split("#", limit = 2)
            val rawName = if (hashSplit.size > 1) safeDecode(hashSplit[1].trim()) else "SS"
            val mainPart = hashSplit[0]
            val (server, port) = if (mainPart.contains("@")) {
                val hostPort = mainPart.substringAfter("@")
                val parts = hostPort.split(":")
                parts.getOrNull(0)?.trim() to (parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 8388)
            } else {
                val decoded = decodeBase64Safe(mainPart) ?: return null
                val parts = decoded.substringAfter("@").split(":")
                parts.getOrNull(0)?.trim() to (parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 8388)
            }
            if (server.isNullOrBlank()) return null
            val suffixedName = "$rawName $subIndex"
            return ProxyConfig(
                name = suffixedName,
                originalName = rawName,
                protocol = ProxyProtocol.SHADOWSOCKS,
                server = server,
                port = port,
                originalServer = server,
                originalPort = port,
                subIndex = subIndex,
                rawUri = raw
            )
        }

        private fun applyCleanIpToUri(
            originalUri: String,
            protocol: ProxyProtocol,
            originalServer: String,
            cleanIp: String,
            newPort: Int
        ): String {
            return try {
                when (protocol) {
                    ProxyProtocol.VLESS, ProxyProtocol.TROJAN -> {
                        val scheme = if (protocol == ProxyProtocol.VLESS) "vless" else "trojan"
                        val withoutScheme = originalUri.substringAfter("://")
                        val userInfo = withoutScheme.substringBefore("@")
                        val afterAt = withoutScheme.substringAfter("@")
                        val queryAndFragment = afterAt.substringAfter("?", "")
                        val fragment = originalUri.substringAfter("#", "")
                        val params = mutableMapOf<String, String>()
                        if (queryAndFragment.isNotEmpty()) {
                            val queryString = queryAndFragment.substringBefore("#")
                            queryString.split("&").forEach { pair ->
                                val kv = pair.split("=", limit = 2)
                                if (kv.isNotEmpty()) {
                                    params[kv[0]] = if (kv.size > 1) kv[1] else ""
                                }
                            }
                        }
                        // Preserve original server domain in SNI/Host so Cloudflare CDN routes it correctly
                        if (!params.containsKey("sni") || params["sni"].isNullOrBlank()) {
                            params["sni"] = originalServer
                        }
                        if (!params.containsKey("host") || params["host"].isNullOrBlank()) {
                            params["host"] = originalServer
                        }
                        val newQuery = params.entries.joinToString("&") { "${it.key}=${it.value}" }
                        val fragPart = if (fragment.isNotEmpty()) "#$fragment" else ""
                        "$scheme://$userInfo@$cleanIp:$newPort?$newQuery$fragPart"
                    }
                    ProxyProtocol.VMESS -> {
                        val b64 = originalUri.substringAfter("vmess://").trim().replace("\\s".toRegex(), "")
                        val decodedJson = decodeBase64Safe(b64) ?: return originalUri
                        val json = JSONObject(decodedJson)
                        val host = json.optString("host", "")
                        val sni = json.optString("sni", "")
                        if (host.isBlank()) json.put("host", originalServer)
                        if (sni.isBlank()) json.put("sni", originalServer)
                        json.put("add", cleanIp)
                        json.put("port", newPort)
                        val newB64 = Base64.encodeToString(
                            json.toString().toByteArray(Charsets.UTF_8),
                            Base64.NO_WRAP
                        )
                        "vmess://$newB64"
                    }
                    ProxyProtocol.SHADOWSOCKS -> originalUri
                    else -> originalUri
                }
            } catch (_: Exception) {
                originalUri
            }
        }

        private fun safeDecode(str: String): String {
            return try {
                URLDecoder.decode(str, "UTF-8")
            } catch (_: Exception) {
                str
            }
        }

        fun decodeBase64Safe(str: String): String? {
            val cleaned = str.trim().replace("\\s".toRegex(), "")
            if (cleaned.isBlank()) return null
            val flags = listOf(Base64.DEFAULT, Base64.URL_SAFE, Base64.NO_WRAP, Base64.NO_PADDING)
            for (f in flags) {
                try {
                    val bytes = Base64.decode(cleaned, f)
                    val s = String(bytes, Charsets.UTF_8)
                    if (s.isNotBlank()) return s
                } catch (_: Exception) {}
            }
            // Try padding
            val padLen = (4 - cleaned.length % 4) % 4
            val padded = cleaned + "=".repeat(padLen)
            for (f in flags) {
                try {
                    val bytes = Base64.decode(padded, f)
                    val s = String(bytes, Charsets.UTF_8)
                    if (s.isNotBlank()) return s
                } catch (_: Exception) {}
            }
            return null
        }
    }
}
