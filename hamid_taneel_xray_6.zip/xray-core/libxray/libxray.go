// Package libxray is a thin gomobile-friendly wrapper around Xray-core for the hamid_taneel Android app.
// Build with: gomobile bind -target=android -androidapi 24 -o libxray.aar ./libxray
package libxray

import (
	"context"
	"net"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/xtls/xray-core/common/platform"
	xnet "github.com/xtls/xray-core/common/net"
	"github.com/xtls/xray-core/core"
	"github.com/xtls/xray-core/features/stats"
	_ "github.com/xtls/xray-core/main/distro/all"
)

var (
	mu       sync.Mutex
	instance *core.Instance
)

// Version returns the Xray-core version string.
func Version() string {
	return core.Version()
}

// Start launches Xray with the given JSON config. tunFd is the file descriptor of the
// Android VpnService TUN interface (used by the "tun" inbound). Pass 0 when the config has no tun inbound.
func Start(configJSON string, tunFd int) error {
	mu.Lock()
	defer mu.Unlock()
	if instance != nil {
		_ = instance.Close()
		instance = nil
	}
	if tunFd > 0 {
		if err := os.Setenv(platform.NormalizeEnvName(platform.TunFdKey), strconv.Itoa(tunFd)); err != nil {
			return err
		}
	}
	inst, err := core.StartInstance("json", []byte(configJSON))
	if err != nil {
		return err
	}
	instance = inst
	return nil
}

// Stop shuts the running instance down.
func Stop() {
	mu.Lock()
	defer mu.Unlock()
	if instance != nil {
		_ = instance.Close()
		instance = nil
	}
}

// IsRunning reports whether an instance is active.
func IsRunning() bool {
	mu.Lock()
	defer mu.Unlock()
	return instance != nil
}

func counter(name string) int64 {
	mu.Lock()
	inst := instance
	mu.Unlock()
	if inst == nil {
		return 0
	}
	m, ok := inst.GetFeature(stats.ManagerType()).(stats.Manager)
	if !ok || m == nil {
		return 0
	}
	c := m.GetCounter(name)
	if c == nil {
		return 0
	}
	return c.Value()
}

// UplinkBytes returns total bytes sent through the "proxy" outbound since Start.
func UplinkBytes() int64 { return counter("outbound>>>proxy>>>traffic>>>uplink") }

// DownlinkBytes returns total bytes received through the "proxy" outbound since Start.
func DownlinkBytes() int64 { return counter("outbound>>>proxy>>>traffic>>>downlink") }

// MeasureDelay starts a temporary Xray instance from an outbound-only config and returns the
// time (ms) of an HTTP GET to url through it, or -1 on failure. Independent from the running VPN instance.
func MeasureDelay(configJSON string, url string, timeoutMs int) int64 {
	inst, err := core.StartInstance("json", []byte(configJSON))
	if err != nil {
		return -1
	}
	defer inst.Close()

	timeout := time.Duration(timeoutMs) * time.Millisecond
	client := &http.Client{
		Timeout: timeout,
		Transport: &http.Transport{
			DisableKeepAlives: true,
			DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
				host, portStr, err := net.SplitHostPort(addr)
				if err != nil {
					return nil, err
				}
				p, err := strconv.Atoi(portStr)
				if err != nil {
					return nil, err
				}
				port, err := xnet.PortFromInt(uint32(p))
				if err != nil {
					return nil, err
				}
				return core.Dial(ctx, inst, xnet.TCPDestination(xnet.ParseAddress(host), port))
			},
		},
		CheckRedirect: func(req *http.Request, via []*http.Request) error { return http.ErrUseLastResponse },
	}

	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return -1
	}
	req.Header.Set("User-Agent", "hamid_taneel/1.0")
	start := time.Now()
	resp, err := client.Do(req)
	if err != nil {
		return -1
	}
	defer resp.Body.Close()
	if resp.StatusCode != 204 && resp.StatusCode != 200 {
		return -1
	}
	return time.Since(start).Milliseconds()
}

