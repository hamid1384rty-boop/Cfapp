Xray-core source (unchanged) + `libxray/` — a small gomobile wrapper used by the Android app
(Start/Stop/MeasureDelay/traffic counters). Build: `../build_xray.sh`.
