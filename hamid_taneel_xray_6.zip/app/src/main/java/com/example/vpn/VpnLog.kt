package com.example.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** In-app log buffer shown in the "لاگ" tab. Keeps the last MAX_LINES entries. */
object VpnLog {
    enum class Level { INFO, WARN, ERROR }

    private const val MAX_LINES = 500
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines.asStateFlow()

    @Synchronized
    fun log(level: Level, tag: String, msg: String) {
        val line = "${timeFmt.format(Date())} [${level.name}] $tag: $msg"
        val current = _lines.value
        _lines.value = if (current.size >= MAX_LINES) {
            current.drop(current.size - MAX_LINES + 1) + line
        } else {
            current + line
        }
    }

    fun i(tag: String, msg: String) = log(Level.INFO, tag, msg)
    fun w(tag: String, msg: String) = log(Level.WARN, tag, msg)

    fun e(tag: String, msg: String, t: Throwable? = null) {
        val detail = if (t != null) "$msg (${t.javaClass.simpleName}: ${t.message})" else msg
        log(Level.ERROR, tag, detail)
    }

    @Synchronized
    fun clear() {
        _lines.value = emptyList()
    }
}
