package com.example.vpn

import android.util.Base64
import com.example.data.model.ProxyConfig
import com.example.data.model.ProxyProtocol
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

/**
 * Converts a ProxyConfig share-link (vless:// vmess:// trojan:// ss://) into an Xray-core JSON config.
 */
object XrayConfigBuilder {

    /** Full config for the VPN: tun inbound (fd given by Android) -> proxy outbound. */
    fun buildVpnConfig(config: ProxyConfig, mtu: Int = 1500): String {
        val outbound = buildOutbound(config) ?: throw IllegalArgumentException("کانفیگ پشتیبانی نمی‌شود")
        val serverHost = outboundHost(config)

        val dnsServers = JSONArray()
        // The proxy server's own domain must be resolved directly (not through the proxy itself)
        if (serverHost.isNotBlank() && !isIp(serverHost)) {
            dnsServers.put(JSONObject().apply {
                put("address", "localhost")
                put("domains", JSONArray().put("full:$serverHost"))
            })
        }
        dnsServers.put("https://1.1.1.1/dns-query")
        dnsServers.put("https://8.8.8.8/dns-query")

        return JSONObject().apply {
            put("log", JSONObject().put("loglevel", "warning"))
            put("stats", JSONObject())
            put("policy", JSONObject().put("system", JSONObject().apply {
                put("statsOutboundUplink", true)
                put("statsOutboundDownlink", true)
            }))
            put("dns", JSONObject().apply {
                put("servers", dnsServers)
                put("queryStrategy", "UseIPv4")
            })
            put("inbounds", JSONArray().put(JSONObject().apply {
                put("tag", "tun-in")
                put("protocol", "tun")
                put("settings", JSONObject().apply {
                    put("name", "tun0")
                    put("mtu", mtu)
                })
                put("sniffing", JSONObject().apply {
                    put("enabled", true)
                    put("destOverride", JSONArray().put("http").put("tls").put("quic"))
                    put("routeOnly", true)
                })
            }))
            put("outbounds", JSONArray().apply {
                put(outbound)
                put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
                put(JSONObject().put("tag", "block").put("protocol", "blackhole"))
                put(JSONObject().put("tag", "dns-out").put("protocol", "dns"))
            })
            put("routing", JSONObject().apply {
                put("domainStrategy", "AsIs")
                put("rules", JSONArray().put(JSONObject().apply {
                    put("type", "field")
                    put("port", "53")
                    put("outboundTag", "dns-out")
                }))
            })
        }.toString()
    }

    /** Outbound-only config used for the "real delay" test. */
    fun buildTestConfig(config: ProxyConfig): String? {
        val outbound = buildOutbound(config) ?: return null
        return JSONObject().apply {
            put("log", JSONObject().put("loglevel", "none"))
            put("outbounds", JSONArray().put(outbound))
        }.toString()
    }

    // ---------------------------------------------------------------- outbound

    private fun buildOutbound(config: ProxyConfig): JSONObject? = try {
        when (config.protocol) {
            ProxyProtocol.VLESS -> vless(config.rawUri)
            ProxyProtocol.VMESS -> vmess(config.rawUri)
            ProxyProtocol.TROJAN -> trojan(config.rawUri)
            ProxyProtocol.SHADOWSOCKS -> shadowsocks(config.rawUri)
            else -> null
        }
    } catch (_: Throwable) {
        null
    }

    private fun outboundHost(config: ProxyConfig): String = config.server.trim().removePrefix("[").removeSuffix("]")

    private fun isIp(s: String) =
        Regex("""^\d{1,3}(\.\d{1,3}){3}$""").matches(s) || s.contains(':')

    private class Link(
        val userInfo: String,
        val host: String,
        val port: Int,
        val params: Map<String, String>
    )

    private fun decode(s: String): String =
        try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { s }

    private fun parseLink(raw: String): Link {
        val noFragment = raw.substringBefore('#')
        val afterScheme = noFragment.substringAfter("://")
        val query = afterScheme.substringAfter('?', "")
        val main = afterScheme.substringBefore('?')
        val userInfo = decode(main.substringBeforeLast('@'))
        val hostPort = main.substringAfterLast('@')
        val host: String
        val port: Int
        if (hostPort.startsWith("[")) {
            host = hostPort.substringAfter('[').substringBefore(']')
            port = hostPort.substringAfter("]:", "443").toIntOrNull() ?: 443
        } else {
            host = hostPort.substringBeforeLast(':', hostPort).trim()
            port = if (hostPort.contains(':')) hostPort.substringAfterLast(':').toIntOrNull() ?: 443 else 443
        }
        val params = HashMap<String, String>()
        if (query.isNotEmpty()) {
            query.split('&').forEach { pair ->
                if (pair.isEmpty()) return@forEach
                val k = pair.substringBefore('=')
                val v = pair.substringAfter('=', "")
                params[k] = decode(v)
            }
        }
        return Link(userInfo, host, port, params)
    }

    private fun vless(raw: String): JSONObject {
        val l = parseLink(raw)
        val p = l.params
        val user = JSONObject().apply {
            put("id", l.userInfo)
            put("encryption", p["encryption"]?.ifBlank { null } ?: "none")
            p["flow"]?.takeIf { it.isNotBlank() }?.let { put("flow", it) }
        }
        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "vless")
            put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject().apply {
                put("address", l.host)
                put("port", l.port)
                put("users", JSONArray().put(user))
            })))
            put("streamSettings", stream(p["type"] ?: "tcp", p["security"] ?: "none", p, l.host))
        }
    }

    private fun trojan(raw: String): JSONObject {
        val l = parseLink(raw)
        val p = l.params
        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "trojan")
            put("settings", JSONObject().apply {
                put("address", l.host)
                put("port", l.port)
                put("password", l.userInfo)
            })
            // trojan is TLS by default
            put("streamSettings", stream(p["type"] ?: "tcp", p["security"] ?: "tls", p, l.host))
        }
    }

    private fun shadowsocks(raw: String): JSONObject {
        var body = raw.substringAfter("ss://").substringBefore('#').substringBefore('?')
        val method: String
        val password: String
        val host: String
        val port: Int
        if (body.contains('@')) {
            val cred = body.substringBeforeLast('@')
            val credDecoded = if (cred.contains(':')) decode(cred) else ProxyConfig.decodeBase64Safe(cred) ?: decode(cred)
            method = credDecoded.substringBefore(':')
            password = credDecoded.substringAfter(':')
            val hp = body.substringAfterLast('@')
            host = hp.substringBeforeLast(':')
            port = hp.substringAfterLast(':').toIntOrNull() ?: 8388
        } else {
            body = ProxyConfig.decodeBase64Safe(body) ?: throw IllegalArgumentException("bad ss")
            val cred = body.substringBeforeLast('@')
            method = cred.substringBefore(':')
            password = cred.substringAfter(':')
            val hp = body.substringAfterLast('@')
            host = hp.substringBeforeLast(':')
            port = hp.substringAfterLast(':').toIntOrNull() ?: 8388
        }
        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "shadowsocks")
            put("settings", JSONObject().apply {
                put("address", host)
                put("port", port)
                put("method", method)
                put("password", password)
            })
        }
    }

    private fun vmess(raw: String): JSONObject {
        val b64 = raw.substringAfter("vmess://").trim().replace("\\s".toRegex(), "")
        val j = JSONObject(ProxyConfig.decodeBase64Safe(b64) ?: throw IllegalArgumentException("bad vmess"))
        val host = j.optString("add")
        val port = j.optString("port", "443").toIntOrNull() ?: 443
        val params = HashMap<String, String>().apply {
            put("type", j.optString("net", "tcp").ifBlank { "tcp" })
            put("headerType", j.optString("type", "none"))
            put("host", j.optString("host", ""))
            put("path", j.optString("path", ""))
            put("sni", j.optString("sni", ""))
            put("alpn", j.optString("alpn", ""))
            put("fp", j.optString("fp", ""))
        }
        val security = if (j.optString("tls") == "tls") "tls" else "none"
        val user = JSONObject().apply {
            put("id", j.optString("id"))
            put("alterId", j.optString("aid", "0").toIntOrNull() ?: 0)
            put("security", j.optString("scy", "auto").ifBlank { "auto" })
        }
        return JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "vmess")
            put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject().apply {
                put("address", host)
                put("port", port)
                put("users", JSONArray().put(user))
            })))
            put("streamSettings", stream(params["type"]!!, security, params, host))
        }
    }

    // ---------------------------------------------------------------- transport

    private fun stream(type: String, security: String, p: Map<String, String>, serverHost: String): JSONObject {
        val s = JSONObject()
        val net = when (type.lowercase()) {
            "ws", "websocket" -> "ws"
            "grpc", "gun" -> "grpc"
            "httpupgrade" -> "httpupgrade"
            "xhttp", "splithttp" -> "xhttp"
            "kcp", "mkcp" -> "kcp"
            else -> "tcp"
        }
        s.put("network", net)

        val hostHeader = p["host"].orEmpty()
        val path = p["path"]?.ifBlank { null } ?: "/"

        when (net) {
            "ws" -> s.put("wsSettings", JSONObject().apply {
                put("path", path)
                if (hostHeader.isNotBlank()) put("host", hostHeader)
            })
            "httpupgrade" -> s.put("httpupgradeSettings", JSONObject().apply {
                put("path", path)
                if (hostHeader.isNotBlank()) put("host", hostHeader)
            })
            "xhttp" -> s.put("xhttpSettings", JSONObject().apply {
                put("path", path)
                if (hostHeader.isNotBlank()) put("host", hostHeader)
                p["mode"]?.takeIf { it.isNotBlank() }?.let { put("mode", it) }
            })
            "grpc" -> s.put("grpcSettings", JSONObject().apply {
                put("serviceName", p["serviceName"] ?: p["path"] ?: "")
                if (p["mode"] == "multi") put("multiMode", true)
            })
            "kcp" -> s.put("kcpSettings", JSONObject().apply {
                put("header", JSONObject().put("type", p["headerType"]?.ifBlank { null } ?: "none"))
                p["seed"]?.takeIf { it.isNotBlank() }?.let { put("seed", it) }
            })
            "tcp" -> if (p["headerType"] == "http") {
                s.put("tcpSettings", JSONObject().put("header", JSONObject().apply {
                    put("type", "http")
                    put("request", JSONObject().apply {
                        put("path", JSONArray().put(path))
                        if (hostHeader.isNotBlank()) {
                            put("headers", JSONObject().put("Host", JSONArray().put(hostHeader)))
                        }
                    })
                }))
            }
        }

        val sni = p["sni"]?.ifBlank { null } ?: hostHeader.ifBlank { null } ?: serverHost
        val alpn = p["alpn"].orEmpty()
        when (security.lowercase()) {
            "tls" -> {
                s.put("security", "tls")
                s.put("tlsSettings", JSONObject().apply {
                    put("serverName", sni)
                    if (alpn.isNotBlank()) put("alpn", JSONArray(alpn.split(',').map { it.trim() }.filter { it.isNotEmpty() }))
                    put("fingerprint", p["fp"]?.ifBlank { null } ?: "chrome")
                    val insecure = p["allowInsecure"] == "1" || p["allowInsecure"] == "true" ||
                        p["insecure"] == "1" || p["insecure"] == "true"
                    if (insecure) put("allowInsecure", true)
                })
            }
            "reality" -> {
                s.put("security", "reality")
                s.put("realitySettings", JSONObject().apply {
                    put("serverName", sni)
                    put("fingerprint", p["fp"]?.ifBlank { null } ?: "chrome")
                    put("publicKey", p["pbk"].orEmpty())
                    put("shortId", p["sid"].orEmpty())
                    put("spiderX", p["spx"].orEmpty())
                })
            }
            else -> s.put("security", "none")
        }
        return s
    }
}
