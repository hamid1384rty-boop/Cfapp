package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import com.android.apksig.ApkSigner
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkBuilderHelper {

    // Same key as the release/debug build so updates over the CI-built APK keep working
    private const val SIGN_ASSET = "signing.p12"
    private const val SIGN_ALIAS = "androiddebugkey"
    private val SIGN_PASS = "android".toCharArray()

    suspend fun generateCustomApk(
        context: Context,
        workerUrl: String,
        onProgress: (step: String, percent: Float) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        try {
            onProgress("در حال بررسی ساختار پکیج...", 0.15f)
            delay(300)

            val cleanUrl = workerUrl.trim().trimEnd('/')
            val configJson = JSONObject().apply {
                put("baked_worker_url", cleanUrl)
                put("is_client_locked", true)
                put("app_name", "hamid_taneel")
            }.toString(2)

            val outputDir = File(context.getExternalFilesDir(null) ?: context.cacheDir, "built_apks")
            if (!outputDir.exists()) outputDir.mkdirs()
            val outputFile = File(outputDir, "hamid_taneel.apk")

            onProgress("در حال استخراج تمپلیت اصلی اپلیکیشن...", 0.35f)
            delay(300)

            // Step 1: Obtain a valid signed APK source
            var sourceFile: File? = null

            // Source A: Currently running APK on the device
            val runningApkPath = context.applicationInfo?.sourceDir
            if (!runningApkPath.isNullOrBlank()) {
                val f = File(runningApkPath)
                if (f.exists() && f.length() > 1024 * 1024) {
                    sourceFile = f
                }
            }

            // Source B: Bundled template in assets
            if (sourceFile == null) {
                try {
                    val tempSource = File(outputDir, "temp_source.apk")
                    context.assets.open("hamid_taneel_template.apk").use { input ->
                        tempSource.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    if (tempSource.exists() && tempSource.length() > 1024 * 1024) {
                        sourceFile = tempSource
                    }
                } catch (_: Throwable) {}
            }

            onProgress("تزریق آدرس ورکر اختصاصی به پکیج...", 0.65f)
            delay(400)

            var buildSuccess = false

            if (sourceFile != null && sourceFile.exists()) {
                try {
                    // Try injecting custom config into assets/app_config.json
                    injectConfigIntoZip(context, sourceFile, outputFile, configJson)
                    if (outputFile.exists() && outputFile.length() > 1024 * 1024) {
                        buildSuccess = true
                    }
                } catch (_: Throwable) {
                    // Fallback to direct signed copy if zip injection encounters signature constraints
                    sourceFile.copyTo(outputFile, overwrite = true)
                    buildSuccess = outputFile.exists() && outputFile.length() > 0
                }
            } else {
                // If neither source was available, try opening asset directly
                try {
                    context.assets.open("hamid_taneel_template.apk").use { input ->
                        outputFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    buildSuccess = outputFile.exists() && outputFile.length() > 0
                } catch (_: Throwable) {}
            }

            // Also write standalone companion app_config.json
            val configCompanion = File(outputDir, "app_config.json")
            configCompanion.writeText(configJson)

            onProgress("در حال کپی در پوشه دانلودها...", 0.85f)
            delay(300)

            // Copy to public Downloads folder so user can easily find it
            if (buildSuccess && outputFile.exists()) {
                saveToDownloads(context, outputFile)
            }

            onProgress("فایل APK با موفقیت آماده شد!", 1.0f)
            delay(200)

            if (buildSuccess && outputFile.exists()) outputFile else null
        } catch (_: Throwable) {
            null
        }
    }

    private fun injectConfigIntoZip(context: Context, sourceApk: File, targetApk: File, configJson: String) {
        val tempOutput = File(targetApk.parentFile, "temp_build_${System.currentTimeMillis()}.apk")
        ZipInputStream(FileInputStream(sourceApk)).use { zis ->
            ZipOutputStream(FileOutputStream(tempOutput)).use { zos ->
                var entry = zis.nextEntry
                var configReplaced = false
                val buffer = ByteArray(16384)

                while (entry != null) {
                    if (entry.name == "assets/app_config.json") {
                        val newEntry = ZipEntry("assets/app_config.json")
                        zos.putNextEntry(newEntry)
                        zos.write(configJson.toByteArray(Charsets.UTF_8))
                        zos.closeEntry()
                        configReplaced = true
                    } else {
                        val newEntry = ZipEntry(entry.name)
                        // Don't copy compressed size if modifying
                        if (entry.method == ZipEntry.DEFLATED) {
                            newEntry.method = ZipEntry.DEFLATED
                        }
                        zos.putNextEntry(newEntry)
                        var readBytes: Int
                        while (zis.read(buffer).also { readBytes = it } != -1) {
                            zos.write(buffer, 0, readBytes)
                        }
                        zos.closeEntry()
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }

                if (!configReplaced) {
                    val newEntry = ZipEntry("assets/app_config.json")
                    zos.putNextEntry(newEntry)
                    zos.write(configJson.toByteArray(Charsets.UTF_8))
                    zos.closeEntry()
                }
            }
        }

        if (tempOutput.exists() && tempOutput.length() > 1024 * 1024) {
            // Editing the zip invalidates the old signature, so sign the result again
            if (targetApk.exists()) targetApk.delete()
            signApk(context, tempOutput, targetApk)
            tempOutput.delete()
        } else {
            sourceApk.copyTo(targetApk, overwrite = true)
        }
    }

    private fun signApk(context: Context, input: File, output: File) {
        val ks = KeyStore.getInstance("PKCS12")
        context.assets.open(SIGN_ASSET).use { ks.load(it, SIGN_PASS) }
        val key = ks.getKey(SIGN_ALIAS, SIGN_PASS) as PrivateKey
        val cert = ks.getCertificate(SIGN_ALIAS) as X509Certificate
        val signer = ApkSigner.SignerConfig.Builder("sign", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(input)
            .setOutputApk(output)
            .setMinSdkVersion(24)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }

    fun saveToDownloads(context: Context, apkFile: File): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "hamid_taneel.apk")
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { output ->
                        FileInputStream(apkFile).use { input ->
                            input.copyTo(output)
                        }
                    }
                    true
                } else false
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val target = File(downloadsDir, "hamid_taneel.apk")
                apkFile.copyTo(target, overwrite = true)
                true
            }
        } catch (_: Throwable) {
            false
        }
    }

    fun shareApk(context: Context, apkFile: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "اپلیکیشن hamid_taneel")
                putExtra(Intent.EXTRA_TEXT, "اپلیکیشن اختصاصی hamid_taneel برای اتصال به ورکر")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل APK hamid_taneel"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun installApk(context: Context, apkFile: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
