package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CloudflarePortCatalog
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun ScannerScreen(viewModel: MainViewModel) {
    val scannerState by viewModel.scannerState.collectAsState()

    var selectedPort by remember { mutableStateOf(443) }
    var selectedMode by remember { mutableStateOf("Normal") } // "Quick", "Normal", "Mega"
    var showApplyDialog by remember { mutableStateOf(false) }

    if (showApplyDialog) {
        ApplyCleanIpDialog(
            onDismiss = { showApplyDialog = false },
            onApply = { ports, useRandom ->
                viewModel.applyScannedIps(ports, useRandom)
                showApplyDialog = false
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Header
        Text(
            text = "اسکنر نودهای سالم کلودفلر (Clean IP)",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "اسکن واقعی رنج‌های ۱۴ گانه Cloudflare و بررسی trace با شبیه‌سازی موتور پایتون",
            color = TextMuted,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Scan Control Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("scanner_control_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Mode Selector Chips
                Text(
                    text = "حالت اسکن:",
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "Quick" to "سریع (نمونه‌برداری)",
                        "Normal" to "عادی (پیشنهادی)",
                        "Mega" to "مگا (چند پورته)",
                        "Clean" to "آی‌پی سفید (همه)"
                    ).forEach { (modeKey, modeTitle) ->
                        FilterChip(
                            selected = selectedMode == modeKey,
                            onClick = { if (!scannerState.isScanning) selectedMode = modeKey },
                            label = { Text(modeTitle, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Port Selector
                Text(
                    text = "پورت هدف:",
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(443, 8443, 2053, 2083, 2087, 2096).take(4).forEach { p ->
                        FilterChip(
                            selected = selectedPort == p,
                            onClick = { if (!scannerState.isScanning) selectedPort = p },
                            label = { Text("$p", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Start / Stop Scan Button
                Button(
                    onClick = {
                        if (scannerState.isScanning) {
                            viewModel.stopIpScan()
                        } else {
                            viewModel.startIpScan(port = selectedPort, scanMode = selectedMode)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("toggle_scan_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (scannerState.isScanning) NeonRed else NeonBlue,
                        contentColor = CyberBg
                    )
                ) {
                    Icon(
                        imageVector = if (scannerState.isScanning) Icons.Default.Stop else Icons.Default.Radar,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (scannerState.isScanning) "توقف اسکن" else "شروع اسکن واقعی",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Status & Progress Bar
                if (scannerState.isScanning || scannerState.testedCount > 0) {
                    val progress = if (scannerState.totalCount > 0) {
                        (scannerState.testedCount.toFloat() / scannerState.totalCount.toFloat()).coerceIn(0f, 1f)
                    } else 0f

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = NeonGreen,
                            trackColor = CyberCardHover
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "تست شده: ${scannerState.testedCount}/${scannerState.totalCount}",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "یافت شده: ${scannerState.aliveCount} نود سالم",
                                color = NeonGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = scannerState.currentIp,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Discovered Results Header & Quick Apply
        if (scannerState.results.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "نودهای کشف شده (${scannerState.results.size})",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Button(
                    onClick = { showApplyDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = CyberBg),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("apply_scanned_ips_button")
                ) {
                    Icon(imageVector = Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("اعمال به تمام کانفیگ‌ها", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Results List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("scanned_ips_list"),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(scannerState.results, key = { "${it.ip}:${it.port}" }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CyberCard),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${item.ip}:${item.port}",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (item.colo.isNotBlank()) "دیتاسنتر: ${item.colo}" else "کلودفلر تایید شده",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }

                            Surface(
                                color = if (item.latencyMs < 150) NeonGreen.copy(alpha = 0.15f)
                                else if (item.latencyMs < 300) NeonYellow.copy(alpha = 0.15f)
                                else NeonOrange.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "${item.latencyMs}ms",
                                    color = if (item.latencyMs < 150) NeonGreen else if (item.latencyMs < 300) NeonYellow else NeonOrange,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
