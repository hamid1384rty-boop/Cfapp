package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppInfo
import com.example.data.repository.AppPreferences
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun SplitTunnelingScreen(viewModel: MainViewModel) {
    val isEnabled by viewModel.isSplitTunnelingEnabled.collectAsState()
    val mode by viewModel.splitTunnelMode.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val isLoading by viewModel.isLoadingApps.collectAsState()
    val searchQuery by viewModel.appSearchQuery.collectAsState()
    val selectedPackages by viewModel.selectedAppPackages.collectAsState()

    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) installedApps
        else installedApps.filter {
            it.appName.contains(searchQuery, ignoreCase = true) ||
            it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Header
        Text(
            text = "تفکیک برنامه‌ها (Split Tunneling)",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "مشخص کنید کدام برنامه‌ها از تونل VPN عبور کنند",
            color = TextMuted,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Master Switch Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("split_tunneling_master_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isEnabled) NeonGreen else CyberBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "فعال‌سازی پروکسی تفکیکی",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isEnabled) "برنامه‌ها طبق تنظیمات زیر فیلتر می‌شوند" else "همه برنامه‌های گوشی از VPN عبور می‌کنند",
                            color = if (isEnabled) NeonGreen else TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { viewModel.setSplitTunnelingEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonGreen,
                            checkedTrackColor = NeonGreen.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.testTag("split_tunneling_master_switch")
                    )
                }

                if (isEnabled) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = CyberBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "نحوه اعمال پروکسی:",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Mode Selection Tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isProxySelected = mode == AppPreferences.MODE_PROXY_SELECTED

                        // Mode 1: Proxy Only Selected
                        Surface(
                            color = if (isProxySelected) NeonBlue.copy(alpha = 0.2f) else CyberCardHover,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isProxySelected) NeonBlue else CyberBorder
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.setSplitTunnelMode(AppPreferences.MODE_PROXY_SELECTED) }
                                .testTag("mode_proxy_selected_button")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FilterList,
                                    contentDescription = null,
                                    tint = if (isProxySelected) NeonBlue else TextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "فقط برنامه‌های انتخابی",
                                    color = if (isProxySelected) NeonBlue else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Mode 2: Bypass Selected
                        val isBypass = mode == AppPreferences.MODE_BYPASS_SELECTED
                        Surface(
                            color = if (isBypass) NeonYellow.copy(alpha = 0.2f) else CyberCardHover,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isBypass) NeonYellow else CyberBorder
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.setSplitTunnelMode(AppPreferences.MODE_BYPASS_SELECTED) }
                                .testTag("mode_bypass_selected_button")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Block,
                                    contentDescription = null,
                                    tint = if (isBypass) NeonYellow else TextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "عبور بدون فیلترشکن (Bypass)",
                                    color = if (isBypass) NeonYellow else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar & Select All / Deselect All
        if (isEnabled) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setAppSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_search_field"),
                placeholder = { Text("جستجوی نام یا پکیج برنامه...", color = TextMuted, fontSize = 12.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextMuted)
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.setAppSearchQuery("") }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = TextMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CyberCard,
                    unfocusedContainerColor = CyberCard,
                    focusedBorderColor = NeonBlue,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${selectedPackages.size} از ${installedApps.size} برنامه انتخاب شده",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = { viewModel.selectAllApps() },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("انتخاب همه", fontSize = 11.sp, color = NeonBlue)
                    }

                    TextButton(
                        onClick = { viewModel.deselectAllApps() },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("پاک کردن", fontSize = 11.sp, color = NeonRed)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // App List
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeonBlue)
            }
        } else if (filteredApps.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (isEnabled) "برنامه‌ای با این مشخصات یافت نشد" else "برای انتخاب برنامه‌ها، کلید بالا را فعال کنید",
                    color = TextMuted,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("installed_apps_list"),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    val isChecked = selectedPackages.contains(app.packageName)
                    AppItemRow(
                        app = app,
                        isChecked = isChecked,
                        isEnabled = isEnabled,
                        onToggle = {
                            if (isEnabled) {
                                viewModel.toggleAppPackage(app.packageName)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AppItemRow(
    app: AppInfo,
    isChecked: Boolean,
    isEnabled: Boolean,
    onToggle: () -> Unit
) {
    Surface(
        color = CyberCard,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isChecked && isEnabled) NeonBlue.copy(alpha = 0.5f) else CyberBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = isEnabled) { onToggle() }
            .testTag("app_row_${app.packageName}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // App Icon or Avatar fallback
                AppIconView(drawable = app.icon, appName = app.appName)

                Column {
                    Text(
                        text = app.appName,
                        color = if (isEnabled) TextPrimary else TextMuted,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                    Text(
                        text = app.packageName,
                        color = TextMuted,
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }

            Checkbox(
                checked = isChecked,
                onCheckedChange = { onToggle() },
                enabled = isEnabled,
                colors = CheckboxDefaults.colors(
                    checkedColor = NeonBlue,
                    checkmarkColor = CyberBg,
                    uncheckedColor = TextMuted
                ),
                modifier = Modifier.testTag("app_checkbox_${app.packageName}")
            )
        }
    }
}

@Composable
private fun AppIconView(drawable: Drawable?, appName: String) {
    if (drawable != null) {
        val bitmap = remember(drawable) {
            try {
                if (drawable is BitmapDrawable && drawable.bitmap != null) {
                    drawable.bitmap
                } else {
                    val w = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 64
                    val h = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 64
                    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val c = Canvas(b)
                    drawable.setBounds(0, 0, c.width, c.height)
                    drawable.draw(c)
                    b
                }
            } catch (_: Throwable) {
                null
            }
        }

        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            return
        }
    }

    // Fallback Initial badge
    val initial = appName.firstOrNull()?.toString()?.uppercase() ?: "A"
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CyberCardHover),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initial,
            color = NeonBlue,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}
