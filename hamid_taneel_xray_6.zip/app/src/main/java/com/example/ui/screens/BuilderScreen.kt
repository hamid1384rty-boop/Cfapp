package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.theme.*
import com.example.util.ApkBuilderHelper
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun BuilderScreen(
    viewModel: MainViewModel,
    onLaunchBuiltApp: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val workerUrl by viewModel.workerUrl.collectAsState()

    var inputUrl by remember { mutableStateOf(workerUrl) }
    var isBuilding by remember { mutableStateOf(false) }
    var buildProgress by remember { mutableFloatStateOf(0f) }
    var buildStep by remember { mutableStateOf("") }
    var generatedApkFile by remember { mutableStateOf<File?>(null) }
    var statusFeedback by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Eagle Brand Header with Avatar
        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .border(2.dp, NeonBlue, CircleShape)
                .background(CyberCard),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.hamid_eagle),
                contentDescription = "لوگوی hamid_taneel",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "پنل ساخت اپلیکیشن hamid_taneel",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "آدرس Cloudflare Worker را وارد کنید تا فایل APK با ورکر مخفی ساخته شود",
            color = TextMuted,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Worker Input Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("builder_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "آدرس ورکر کلودفلر (Cloudflare Worker URL):",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                OutlinedTextField(
                    value = inputUrl,
                    onValueChange = { inputUrl = it },
                    placeholder = { Text("مثال: https://my-worker.workers.dev", color = TextMuted, fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("builder_worker_url_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CyberCardHover,
                        unfocusedContainerColor = CyberCardHover,
                        focusedBorderColor = NeonBlue,
                        unfocusedBorderColor = CyberBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                if (isBuilding) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        LinearProgressIndicator(
                            progress = { buildProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = NeonGreen,
                            trackColor = CyberCardHover
                        )
                        Text(
                            text = buildStep,
                            color = NeonGreen,
                            fontSize = 12.sp
                        )
                    }
                }

                Button(
                    onClick = {
                        var clean = inputUrl.trim().trimEnd('/')
                        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
                            clean = "https://$clean"
                        }
                        inputUrl = clean
                        viewModel.lockAndBuildClientApp(clean)
                        isBuilding = true
                        statusFeedback = ""
                        coroutineScope.launch {
                            val file = ApkBuilderHelper.generateCustomApk(
                                context = context,
                                workerUrl = clean,
                                onProgress = { step, pct ->
                                    buildStep = step
                                    buildProgress = pct
                                }
                            )
                            isBuilding = false
                            generatedApkFile = file
                            if (file != null && file.exists()) {
                                statusFeedback = "فایل APK با موفقیت تولید شد و در پوشه دانلودها قرار گرفت!"
                                Toast.makeText(context, statusFeedback, Toast.LENGTH_LONG).show()
                            } else {
                                statusFeedback = "خطا در استخراج پکیج APK"
                            }
                        }
                    },
                    enabled = !isBuilding && inputUrl.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("build_apk_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = CyberBg)
                ) {
                    Icon(imageVector = Icons.Default.Build, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ساخت فایل نهایی APK", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                if (statusFeedback.isNotBlank()) {
                    Text(
                        text = statusFeedback,
                        color = if (generatedApkFile != null) NeonGreen else NeonRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Actions for Built APK
        if (generatedApkFile != null) {
            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("built_apk_actions_card"),
                colors = CardDefaults.cardColors(containerColor = CyberCardHover),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen)
                        Text(
                            text = "فایل hamid_taneel.apk آماده است",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Text(
                        text = "می‌توانید فایل APK را مستقیماً نصب کنید، در دانلودها ذخیره کنید، یا برای کاربران خود ارسال نمایید.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    // 1. Install directly
                    Button(
                        onClick = {
                            generatedApkFile?.let { ApkBuilderHelper.installApk(context, it) }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("install_apk_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonBlue, contentColor = CyberBg),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.InstallMobile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("نصب مستقیم فایل APK روی گوشی", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    // 2. Share APK
                    OutlinedButton(
                        onClick = {
                            generatedApkFile?.let { ApkBuilderHelper.shareApk(context, it) }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("share_apk_button"),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ارسال و اشتراک فایل APK (تلگرام، واتساپ)", fontSize = 13.sp)
                    }

                    // 3. Save to Downloads
                    OutlinedButton(
                        onClick = {
                            generatedApkFile?.let {
                                val ok = ApkBuilderHelper.saveToDownloads(context, it)
                                val msg = if (ok) "فایل در پوشه Download/hamid_taneel.apk ذخیره شد" else "خطا در کپی به دانلودها"
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("save_downloads_button"),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ذخیره در پوشه دانلودها (Downloads)", fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Direct test entry into Client Mode
        OutlinedButton(
            onClick = {
                var clean = inputUrl.trim().trimEnd('/')
                if (clean.isNotBlank()) {
                    if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
                        clean = "https://$clean"
                    }
                    viewModel.lockAndBuildClientApp(clean)
                }
                onLaunchBuiltApp()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("enter_client_mode_button"),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
        ) {
            Icon(imageVector = Icons.Default.Login, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("ورود به محیط کاربری اپلیکیشن", fontSize = 13.sp)
        }
    }
}
