package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.flow.collectLatest

enum class AppTab(val title: String, val icon: ImageVector, val tag: String) {
    HOME("اتصال", Icons.Default.PowerSettingsNew, "tab_home"),
    CONFIGS("کانفیگ‌ها", Icons.Default.Tune, "tab_configs"),
    SCANNER("اسکنر IP", Icons.Default.Radar, "tab_scanner"),
    APPS("برنامه‌ها", Icons.Default.Apps, "tab_apps"),
    WHITELIST("لیست سفید", Icons.Default.Shield, "tab_whitelist"),
    LOGS("لاگ", Icons.Default.List, "tab_logs"),
    PROFILE("حساب", Icons.Default.AccountCircle, "tab_profile")
}

@Composable
fun MainApp(
    viewModel: MainViewModel,
    onRequestVpnToggle: () -> Unit = {}
) {
    val isClientLocked by viewModel.isClientLocked.collectAsState()
    val configs by viewModel.configs.collectAsState()

    // Builder (unlocked) -> "builder"; client app -> "import" until at least one config exists, then "main"
    var builderMode by remember { mutableStateOf(!isClientLocked) }
    val activeMode = when {
        builderMode -> "builder"
        configs.isEmpty() -> "import"
        else -> "main"
    }

    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.notification.collectLatest { notif ->
            snackbarHostState.showSnackbar(
                message = notif.message,
                duration = SnackbarDuration.Short
            )
        }
    }

    // Persian RTL layout
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = {
                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier.padding(bottom = 80.dp)
                ) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = CyberCardHover,
                        contentColor = TextPrimary,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            bottomBar = {
                if (activeMode == "main") {
                    NavigationBar(
                        containerColor = CyberCard,
                        contentColor = TextPrimary,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("bottom_nav_bar")
                    ) {
                        AppTab.entries.forEach { tab ->
                            val isSelected = selectedTab == tab
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        tint = if (isSelected) NeonBlue else TextMuted
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.title,
                                        color = if (isSelected) NeonBlue else TextMuted,
                                        fontSize = 10.sp,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CyberCardHover
                                ),
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (activeMode == "main") innerPadding else PaddingValues(0.dp))
                    .background(CyberBg)
            ) {
                when (activeMode) {
                    "builder" -> {
                        BuilderScreen(
                            viewModel = viewModel,
                            onLaunchBuiltApp = {
                                builderMode = false
                            }
                        )
                    }
                    "import" -> {
                        ImportConfigScreen(viewModel = viewModel)
                    }
                    "main" -> {
                        when (selectedTab) {
                            AppTab.HOME -> HomeScreen(
                                viewModel = viewModel,
                                onRequestVpnToggle = onRequestVpnToggle,
                                onNavigateToConfigs = { selectedTab = AppTab.CONFIGS },
                                onNavigateToApps = { selectedTab = AppTab.APPS }
                            )
                            AppTab.CONFIGS -> ConfigsScreen(viewModel = viewModel)
                            AppTab.SCANNER -> ScannerScreen(viewModel = viewModel)
                            AppTab.APPS -> SplitTunnelingScreen(viewModel = viewModel)
                            AppTab.WHITELIST -> WhitelistScreen(viewModel = viewModel)
                            AppTab.LOGS -> LogsScreen()
                            AppTab.PROFILE -> ProfileScreen(
                                viewModel = viewModel,
                                onNavigateToBuilder = { builderMode = true }
                            )
                        }
                    }
                }
            }
        }
    }
}
