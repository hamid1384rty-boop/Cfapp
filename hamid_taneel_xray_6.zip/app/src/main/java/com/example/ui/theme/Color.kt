package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBg = Color(0xFF0B0D14)
val CyberBgSecondary = Color(0xFF10131E)
val CyberCard = Color(0xFF161A29)
val CyberCardHover = Color(0xFF1F253B)
val CyberBorder = Color(0xFF28304D)

val NeonBlue = Color(0xFF00D2FF)
val NeonBlueGlow = Color(0xFF0070F3)
val NeonGreen = Color(0xFF00E676)
val NeonGreenGlow = Color(0xFF00B0FF)
val NeonYellow = Color(0xFFFFD600)
val NeonOrange = Color(0xFFFF9100)
val NeonRed = Color(0xFFFF3366)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B9CC)
val TextMuted = Color(0xFF6B7280)
val StatusConnected = Color(0xFF00E676)
val StatusConnecting = Color(0xFFFFD600)
val StatusDisconnected = Color(0xFF9E9E9E)
