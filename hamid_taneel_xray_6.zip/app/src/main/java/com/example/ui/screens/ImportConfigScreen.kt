package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.theme.*

/** First screen of the client app: configs are added either as a subscription link or as a direct vless:// link. */
@Composable
fun ImportConfigScreen(viewModel: MainViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("import_config_card"),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .border(2.dp, NeonBlue, CircleShape)
                        .background(CyberCardHover),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.hamid_eagle),
                        contentDescription = "لوگوی hamid_taneel",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
                Text(
                    text = "hamid_taneel",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                ImportConfigForm(viewModel = viewModel)
            }
        }
    }
}

/** Shared input form (used on the first screen and in the "add config" dialog). */
@Composable
fun ImportConfigForm(viewModel: MainViewModel, onSuccess: () -> Unit = {}) {
    var input by remember { mutableStateOf("") }
    val isImporting by viewModel.isImporting.collectAsState()
    val importError by viewModel.importError.collectAsState()
    val clipboard = LocalClipboardManager.current

    DisposableEffect(Unit) {
        onDispose { viewModel.clearImportError() }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "لینک ساب (سابسکریپشن) یا کانفیگ vless:// را وارد کنید",
            color = TextMuted,
            fontSize = 12.sp
        )

        importError?.let { err ->
            Text(text = err, color = NeonRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }

        OutlinedTextField(
            value = input,
            onValueChange = {
                input = it
                if (importError != null) viewModel.clearImportError()
            },
            label = { Text("https://... یا vless://...") },
            leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = TextMuted) },
            minLines = 3,
            maxLines = 6,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("import_config_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CyberCardHover,
                unfocusedContainerColor = CyberCardHover,
                focusedBorderColor = NeonBlue,
                unfocusedBorderColor = CyberBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        OutlinedButton(
            onClick = {
                clipboard.getText()?.text?.let { input = it }
            },
            modifier = Modifier.fillMaxWidth().height(44.dp),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
        ) {
            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("چسباندن از کلیپ‌بورد", fontSize = 13.sp)
        }

        Button(
            onClick = { viewModel.importFromInput(input) { ok -> if (ok) { input = ""; onSuccess() } } },
            enabled = !isImporting && input.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("import_config_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NeonBlue, contentColor = CyberBg)
        ) {
            if (isImporting) {
                CircularProgressIndicator(color = CyberBg, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            } else {
                Text("افزودن کانفیگ", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}
