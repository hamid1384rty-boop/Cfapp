package com.example

import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.MainApp
import com.example.ui.MainViewModel
import com.example.ui.theme.CyberBg
import com.example.ui.theme.MyApplicationTheme
import com.example.vpn.VpnConnectionState

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val vpnPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        viewModel.toggleVpn(this)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CyberBg
                ) {
                    MainApp(
                        viewModel = viewModel,
                        onRequestVpnToggle = {
                            val currentState = viewModel.vpnState.value
                            if (currentState == VpnConnectionState.CONNECTED || currentState == VpnConnectionState.CONNECTING) {
                                viewModel.toggleVpn(this)
                            } else {
                                val prepareIntent = try {
                                    VpnService.prepare(this)
                                } catch (_: Exception) {
                                    null
                                }
                                if (prepareIntent != null) {
                                    vpnPermissionLauncher.launch(prepareIntent)
                                } else {
                                    viewModel.toggleVpn(this)
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}
