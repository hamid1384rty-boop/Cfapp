package com.example.data.repository

import com.example.data.model.LoginResponse
import com.example.data.model.ProxyConfig
import com.example.data.model.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class WorkerRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    suspend fun login(
        workerUrl: String,
        username: String,
        pass: String
    ): Result<LoginResponse> = withContext(Dispatchers.IO) {
        val cleanBaseUrl = workerUrl.trim().trimEnd('/')
        if (cleanBaseUrl.isBlank()) {
            return@withContext Result.failure(Exception("آدرس ورکر مشخص نشده است"))
        }

        val endpoint = "$cleanBaseUrl/api/app/login"
        val payload = JSONObject().apply {
            put("username", username)
            put("password", pass)
        }
        val requestBody = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(endpoint)
            .post(requestBody)
            .build()

        try {
            val response = client.newCall(request).execute()
            val bodyString = response.body?.string() ?: ""

            if (!response.isSuccessful && bodyString.isBlank()) {
                return@withContext Result.failure(Exception("خطای سرور: کد ${response.code}"))
            }

            val json = JSONObject(bodyString)
            val ok = json.optBoolean("ok", false)
            if (!ok) {
                val errorMsg = json.optString("error", "نام کاربری یا رمز عبور نامعتبر است")
                return@withContext Result.failure(Exception(errorMsg))
            }

            val userObj = json.optJSONObject("user")
            val userProfile = if (userObj != null) {
                UserProfile(
                    name = userObj.optString("name", username),
                    quotaBytes = userObj.optLong("quotaBytes", 0L),
                    usedBytes = userObj.optLong("usedBytes", 0L),
                    expiresAt = userObj.optString("expiresAt", "")
                )
            } else {
                UserProfile(name = username)
            }

            val subsList = mutableListOf<String>()
            val subsArr = json.optJSONArray("subs")
            if (subsArr != null) {
                for (i in 0 until subsArr.length()) {
                    val s = subsArr.getString(i).trim()
                    if (s.isNotBlank()) subsList.add(s)
                }
            }

            Result.success(
                LoginResponse(
                    ok = true,
                    user = userProfile,
                    subs = subsList
                )
            )
        } catch (e: Exception) {
            Result.failure(Exception("خطا در برقراری ارتباط: ${e.localizedMessage}"))
        }
    }

    class AccessStatus(val allowed: Boolean, val reason: String, val usedBytes: Long, val quotaBytes: Long)

    /** Asks the worker if this account can use the service right now. Null if it could not be checked. */
    suspend fun checkAccess(workerUrl: String, username: String, pass: String): AccessStatus? = withContext(Dispatchers.IO) {
        val base = workerUrl.trim().trimEnd('/')
        if (base.isBlank()) return@withContext null
        try {
            val body = JSONObject().apply {
                put("username", username)
                put("password", pass)
            }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url("$base/api/app/status").post(body).build()
            client.newCall(request).execute().use { response ->
                val json = JSONObject(response.body?.string() ?: return@withContext null)
                if (!json.optBoolean("ok", false)) return@withContext null
                AccessStatus(
                    allowed = json.optBoolean("allowed", true),
                    reason = json.optString("reason", ""),
                    usedBytes = json.optLong("usedBytes", 0L),
                    quotaBytes = json.optLong("quotaBytes", 0L)
                )
            }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Fetches subscription configs from all provided sub URLs.
     * For each sub URL at 1-based index (1, 2, ...), the parsed configs receive a suffix:
     * e.g. "Config Name 1" for Sub 1, "Config Name 2" for Sub 2.
     */
    suspend fun fetchConfigsFromSubs(subUrls: List<String>): List<ProxyConfig> =
        withContext(Dispatchers.IO) {
            val allConfigs = mutableListOf<ProxyConfig>()
            subUrls.forEachIndexed { index, subUrl ->
                val subNumber = index + 1 // 1-based index (ساب 1, ساب 2, ...)
                val trimmedUrl = subUrl.trim()
                if (trimmedUrl.isBlank()) return@forEachIndexed

                try {
                    val request = Request.Builder()
                        .url(trimmedUrl)
                        .header("User-Agent", "v2rayNG/1.8.5 hamid_taneel/1.0 (Android)")
                        .header("Accept", "*/*")
                        .build()

                    val response = client.newCall(request).execute()
                    val rawBody = response.body?.string()?.trim() ?: ""
                    if (rawBody.isNotBlank()) {
                        val proxyLines = extractProxyLines(rawBody)
                        for (line in proxyLines) {
                            val parsed = ProxyConfig.parse(line.trim(), subNumber)
                            if (parsed != null) {
                                allConfigs.add(parsed)
                            }
                        }
                    }
                } catch (_: Exception) {
                    // Continue with remaining subs
                }
            }
            allConfigs
        }

    private fun extractProxyLines(content: String): List<String> {
        val result = mutableListOf<String>()
        val trimmed = content.trim()

        // 1. Try decoding as full Base64
        val decoded = ProxyConfig.decodeBase64Safe(trimmed.replace("\r", "").replace("\n", ""))
        val textToParse = if (decoded != null && (decoded.contains("://") || decoded.contains("proxies:"))) {
            decoded
        } else {
            trimmed
        }

        // 2. Parse line by line
        val lines = textToParse.split("\r\n", "\n", "\r")
        for (line in lines) {
            val l = line.trim()
            if (l.startsWith("vless://", ignoreCase = true) ||
                l.startsWith("vmess://", ignoreCase = true) ||
                l.startsWith("trojan://", ignoreCase = true) ||
                l.startsWith("ss://", ignoreCase = true)
            ) {
                result.add(l)
            } else if (l.length > 25 && !l.contains(" ") && !l.startsWith("#") && !l.startsWith("-")) {
                // Individual line might be base64
                val decLine = ProxyConfig.decodeBase64Safe(l)
                if (decLine != null && decLine.contains("://")) {
                    decLine.split("\r\n", "\n", "\r").forEach { subL ->
                        val subTrimmed = subL.trim()
                        if (subTrimmed.isNotBlank() && subTrimmed.contains("://")) {
                            result.add(subTrimmed)
                        }
                    }
                }
            }
        }
        return result
    }
}
