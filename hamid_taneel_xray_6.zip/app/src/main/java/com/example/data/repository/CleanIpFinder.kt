package com.example.data.repository

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Port of the Python "Clean IP Finder" (scanner.py):
 * - _split_to_24s + generate_cf_ips(sample=0): every host of every /24 in the CF ranges, /24 blocks shuffled
 * - _tls_probe(validate=True): TCP + TLS (SNI speed.cloudflare.com), then GET / and check for
 *   "server: cloudflare" or "cf-ray:" in the response. Latency = TLS handshake time.
 * - scan_clean_ips: batches of 50k, bounded concurrency, sorted by latency. First 20 are shown.
 */
object CleanIpFinder {
    const val SNI = "speed.cloudflare.com"
    const val PORT = 443
    const val TOP_N = 20
    const val BATCH = 50_000
    const val WORKERS = 500
    const val TIMEOUT_MS = 3000

    private val sslContext: SSLContext by lazy {
        val trustAll = arrayOf<TrustManager>(object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            override fun checkClientTrusted(certs: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(certs: Array<X509Certificate>, authType: String) {}
        })
        SSLContext.getInstance("TLS").apply { init(null, trustAll, SecureRandom()) }
    }

    /** Returns every host IP (as Int bits) in the given IPv4 CIDRs, split into /24 blocks, blocks shuffled. */
    fun buildAllIps(subnets: List<String>): IntArray {
        val seen = HashSet<Long>()
        val blocks = ArrayList<Long>()
        for (cidr in subnets) {
            val parts = cidr.trim().split("/")
            if (parts.size != 2) continue
            val prefix = parts[1].toIntOrNull() ?: continue
            val base = ipToLong(parts[0]) ?: continue
            if (prefix !in 0..24) continue // none of the CF ranges are narrower than /24
            val net = base and (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
            val count = 1L shl (24 - prefix)
            for (i in 0 until count) {
                val block = net + i * 256
                if (seen.add(block)) blocks.add(block)
            }
        }
        blocks.shuffle()
        val out = IntArray(blocks.size * 254)
        var k = 0
        for (block in blocks) {
            for (h in 1..254) out[k++] = (block + h).toInt() // skip .0 and .255
        }
        return out
    }

    /**
     * Probes every IP. onProgress(done, aliveCount, topN) is called periodically.
     * Returns all alive IPs sorted by latency.
     */
    suspend fun scan(
        ips: IntArray,
        workers: Int = WORKERS,
        timeoutMs: Int = TIMEOUT_MS,
        onProgress: (done: Int, alive: Int, top: List<Pair<String, Long>>) -> Unit
    ): List<Pair<String, Long>> = coroutineScope {
        val sem = Semaphore(workers)
        val lock = Any()
        val alive = ArrayList<Pair<String, Long>>()
        var done = 0
        var start = 0
        while (start < ips.size && isActive) {
            val end = minOf(start + BATCH, ips.size)
            val jobs = (start until end).map { idx ->
                launch(Dispatchers.IO) {
                    sem.withPermit {
                        val ip = longToIp(ips[idx].toLong() and 0xFFFFFFFFL)
                        val lat = tlsProbe(ip, timeoutMs)
                        synchronized(lock) {
                            done++
                            if (lat != null) alive.add(ip to lat)
                            if (lat != null || done % 1000 == 0) {
                                onProgress(done, alive.size, alive.sortedBy { it.second }.take(TOP_N))
                            }
                        }
                    }
                }
            }
            jobs.joinAll()
            start = end
        }
        synchronized(lock) { alive.sortedBy { it.second } }
    }

    /** Python _tls_probe with validate=True. Returns TLS latency in ms if the edge answers as Cloudflare. */
    private fun tlsProbe(ip: String, timeoutMs: Int): Long? {
        var socket: Socket? = null
        return try {
            socket = Socket()
            socket.tcpNoDelay = true
            val t0 = System.nanoTime()
            socket.connect(InetSocketAddress(ip, PORT), timeoutMs)
            socket.soTimeout = timeoutMs

            val ssl = sslContext.socketFactory.createSocket(socket, SNI, PORT, true) as SSLSocket
            ssl.useClientMode = true
            val params = ssl.sslParameters
            params.serverNames = listOf(SNIHostName(SNI))
            ssl.sslParameters = params
            ssl.soTimeout = timeoutMs
            ssl.startHandshake()
            val tlsMs = (System.nanoTime() - t0) / 1_000_000

            val req = "GET / HTTP/1.1\r\nHost: $SNI\r\nConnection: close\r\n\r\n"
            ssl.outputStream.write(req.toByteArray(Charsets.ISO_8859_1))
            ssl.outputStream.flush()

            val buf = ByteArray(2048)
            val n = ssl.inputStream.read(buf)
            val head = if (n > 0) String(buf, 0, n, Charsets.ISO_8859_1).lowercase() else ""
            val isCf = head.contains("server: cloudflare") || head.contains("cf-ray:")
            if (isCf) tlsMs else null
        } catch (_: Throwable) {
            null
        } finally {
            try { socket?.close() } catch (_: Throwable) {}
        }
    }

    private fun ipToLong(s: String): Long? {
        val p = s.trim().split(".")
        if (p.size != 4) return null
        var r = 0L
        for (x in p) {
            val v = x.toIntOrNull() ?: return null
            if (v !in 0..255) return null
            r = (r shl 8) or v.toLong()
        }
        return r
    }

    private fun longToIp(v: Long): String =
        "${(v shr 24) and 255}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}"
}
