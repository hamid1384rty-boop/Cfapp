package com.example.data.model

data class CloudflarePort(
    val port: Int,
    val isTls: Boolean,
    val label: String
)

object CloudflarePortCatalog {
    val ALL_PORTS: List<CloudflarePort> = listOf(
        CloudflarePort(443, true, "443 (HTTPS / TLS)"),
        CloudflarePort(8443, true, "8443 (TLS)"),
        CloudflarePort(2053, true, "2053 (TLS)"),
        CloudflarePort(2083, true, "2083 (TLS)"),
        CloudflarePort(2087, true, "2087 (TLS)"),
        CloudflarePort(2096, true, "2096 (TLS)"),
        CloudflarePort(80, false, "80 (HTTP / بدون TLS)"),
        CloudflarePort(8080, false, "8080 (بدون TLS)"),
        CloudflarePort(8880, false, "8880 (بدون TLS)"),
        CloudflarePort(2052, false, "2052 (بدون TLS)")
    )
}

data class CleanIp(
    val id: String = java.util.UUID.randomUUID().toString(),
    val ip: String,
    val port: Int = 443,
    val latencyMs: Long? = null,
    val speedMbps: Double? = null,
    val isAlive: Boolean = true,
    val addedAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)
