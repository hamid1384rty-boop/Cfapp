package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.CleanIp
import com.example.data.model.ProxyConfig
import com.example.data.model.ProxyProtocol
import com.example.data.model.UserProfile
import org.json.JSONArray
import org.json.JSONObject

class AppPreferences(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hamid_taneel_prefs", Context.MODE_PRIVATE)

    init {
        loadBundledAssetConfig()
    }

    private fun loadBundledAssetConfig() {
        try {
            val assetManager = context.assets
            val inputStream = assetManager.open("app_config.json")
            val jsonStr = inputStream.bufferedReader().use { it.readText() }
            val obj = JSONObject(jsonStr)
            val bundledUrl = obj.optString("baked_worker_url", "").trim().trimEnd('/')
            val bundledLocked = obj.optBoolean("is_client_locked", false)
            if (bundledUrl.isNotBlank()) {
                if (bakedWorkerUrl.isBlank()) {
                    bakedWorkerUrl = bundledUrl
                    workerUrl = bundledUrl
                }
                if (bundledLocked && !isClientLocked) {
                    isClientLocked = true
                }
            }
        } catch (_: Exception) {}
    }

    var isClientLocked: Boolean
        get() = prefs.getBoolean(KEY_IS_CLIENT_LOCKED, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_CLIENT_LOCKED, value).apply()

    var bakedWorkerUrl: String
        get() = prefs.getString(KEY_BAKED_WORKER_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_BAKED_WORKER_URL, value.trim().trimEnd('/')).apply()

    var workerUrl: String
        get() {
            val baked = bakedWorkerUrl
            if (baked.isNotBlank()) return baked
            return prefs.getString(KEY_WORKER_URL, "") ?: ""
        }
        set(value) {
            val clean = value.trim().trimEnd('/')
            prefs.edit().putString(KEY_WORKER_URL, clean).apply()
        }

    var username: String
        get() = prefs.getString(KEY_USERNAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USERNAME, value).apply()

    var password: String
        get() = prefs.getString(KEY_PASSWORD, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PASSWORD, value).apply()

    var selectedConfigId: String?
        get() = prefs.getString(KEY_SELECTED_CONFIG_ID, null)
        set(value) = prefs.edit().putString(KEY_SELECTED_CONFIG_ID, value).apply()

    // Split Tunneling Settings
    var isSplitTunnelingEnabled: Boolean
        get() = prefs.getBoolean(KEY_SPLIT_TUNNELING_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_SPLIT_TUNNELING_ENABLED, value).apply()

    var splitTunnelMode: String
        get() = prefs.getString(KEY_SPLIT_TUNNEL_MODE, MODE_PROXY_SELECTED) ?: MODE_PROXY_SELECTED
        set(value) = prefs.edit().putString(KEY_SPLIT_TUNNEL_MODE, value).apply()

    var selectedAppPackages: Set<String>
        get() = prefs.getStringSet(KEY_SELECTED_APP_PACKAGES, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_SELECTED_APP_PACKAGES, value).apply()

    fun lockAppForClient(targetWorkerUrl: String) {
        val clean = targetWorkerUrl.trim().trimEnd('/')
        bakedWorkerUrl = clean
        workerUrl = clean
        isClientLocked = true
        clearAuth()
    }

    fun unlockBuilderMode() {
        isClientLocked = false
    }

    fun saveUserProfile(user: UserProfile) {
        val json = JSONObject().apply {
            put("name", user.name)
            put("quotaBytes", user.quotaBytes)
            put("usedBytes", user.usedBytes)
            put("expiresAt", user.expiresAt)
        }
        prefs.edit().putString(KEY_USER_PROFILE, json.toString()).apply()
    }

    fun getUserProfile(): UserProfile? {
        val str = prefs.getString(KEY_USER_PROFILE, null) ?: return null
        return try {
            val json = JSONObject(str)
            UserProfile(
                name = json.optString("name", ""),
                quotaBytes = json.optLong("quotaBytes", 0L),
                usedBytes = json.optLong("usedBytes", 0L),
                expiresAt = json.optString("expiresAt", "")
            )
        } catch (_: Exception) {
            null
        }
    }

    fun saveSubs(subs: List<String>) {
        val arr = JSONArray()
        subs.forEach { arr.put(it) }
        prefs.edit().putString(KEY_SUBS, arr.toString()).apply()
    }

    fun getSubs(): List<String> {
        val str = prefs.getString(KEY_SUBS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(str)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveConfigs(configs: List<ProxyConfig>) {
        val arr = JSONArray()
        configs.forEach { cfg ->
            val obj = JSONObject().apply {
                put("id", cfg.id)
                put("name", cfg.name)
                put("originalName", cfg.originalName)
                put("protocol", cfg.protocol.name)
                put("server", cfg.server)
                put("port", cfg.port)
                put("originalServer", cfg.originalServer)
                put("originalPort", cfg.originalPort)
                put("subIndex", cfg.subIndex)
                put("rawUri", cfg.rawUri)
                put("pingMs", cfg.pingMs ?: -1L)
                put("isCleanIpApplied", cfg.isCleanIpApplied)
                put("cleanIpUsed", cfg.cleanIpUsed ?: "")
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_CONFIGS, arr.toString()).apply()
    }

    fun getConfigs(): List<ProxyConfig> {
        val str = prefs.getString(KEY_CONFIGS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(str)
            val list = mutableListOf<ProxyConfig>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val ping = obj.optLong("pingMs", -1L)
                list.add(
                    ProxyConfig(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", "Config"),
                        originalName = obj.optString("originalName", "Config"),
                        protocol = try {
                            ProxyProtocol.valueOf(obj.optString("protocol", "OTHER"))
                        } catch (_: Exception) {
                            ProxyProtocol.OTHER
                        },
                        server = obj.optString("server", ""),
                        port = obj.optInt("port", 443),
                        originalServer = obj.optString("originalServer", ""),
                        originalPort = obj.optInt("originalPort", 443),
                        subIndex = obj.optInt("subIndex", 1),
                        rawUri = obj.optString("rawUri", ""),
                        pingMs = if (ping >= 0) ping else null,
                        isCleanIpApplied = obj.optBoolean("isCleanIpApplied", false),
                        cleanIpUsed = obj.optString("cleanIpUsed", "").takeIf { it.isNotBlank() }
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCleanIps(ips: List<CleanIp>) {
        val arr = JSONArray()
        ips.forEach { item ->
            val obj = JSONObject().apply {
                put("id", item.id)
                put("ip", item.ip)
                put("port", item.port)
                put("latencyMs", item.latencyMs ?: -1L)
                put("speedMbps", item.speedMbps ?: -1.0)
                put("isAlive", item.isAlive)
                put("addedAt", item.addedAt)
                put("notes", item.notes)
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_CLEAN_IPS, arr.toString()).apply()
    }

    fun getCleanIps(): List<CleanIp> {
        val str = prefs.getString(KEY_CLEAN_IPS, null) ?: return defaultCleanIps()
        return try {
            val arr = JSONArray(str)
            val list = mutableListOf<CleanIp>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val lat = obj.optLong("latencyMs", -1L)
                val spd = obj.optDouble("speedMbps", -1.0)
                list.add(
                    CleanIp(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        ip = obj.optString("ip", ""),
                        port = obj.optInt("port", 443),
                        latencyMs = if (lat >= 0) lat else null,
                        speedMbps = if (spd >= 0) spd else null,
                        isAlive = obj.optBoolean("isAlive", true),
                        addedAt = obj.optLong("addedAt", System.currentTimeMillis()),
                        notes = obj.optString("notes", "")
                    )
                )
            }
            if (list.isEmpty()) defaultCleanIps() else list
        } catch (_: Exception) {
            defaultCleanIps()
        }
    }

    private fun defaultCleanIps(): List<CleanIp> {
        return listOf(
            CleanIp(ip = "104.16.132.229", port = 443, latencyMs = 115, notes = "نود برتر CF"),
            CleanIp(ip = "104.17.65.1", port = 443, latencyMs = 135, notes = "نود پایدار CF"),
            CleanIp(ip = "162.159.153.4", port = 443, latencyMs = 125, notes = "نود سریع CF"),
            CleanIp(ip = "172.67.180.12", port = 443, latencyMs = 148, notes = "نود CF"),
            CleanIp(ip = "104.24.10.15", port = 443, latencyMs = 108, notes = "نود CF")
        )
    }

    fun clearAuth() {
        prefs.edit()
            .remove(KEY_USERNAME)
            .remove(KEY_PASSWORD)
            .remove(KEY_USER_PROFILE)
            .remove(KEY_SUBS)
            .remove(KEY_CONFIGS)
            .remove(KEY_SELECTED_CONFIG_ID)
            .apply()
    }

    companion object {
        private const val KEY_IS_CLIENT_LOCKED = "is_client_locked"
        private const val KEY_BAKED_WORKER_URL = "baked_worker_url"
        private const val KEY_WORKER_URL = "worker_url"
        private const val KEY_USERNAME = "username"
        private const val KEY_PASSWORD = "password"
        private const val KEY_USER_PROFILE = "user_profile"
        private const val KEY_SUBS = "subs"
        private const val KEY_CONFIGS = "configs"
        private const val KEY_CLEAN_IPS = "clean_ips"
        private const val KEY_SELECTED_CONFIG_ID = "selected_config_id"

        private const val KEY_SPLIT_TUNNELING_ENABLED = "split_tunneling_enabled"
        private const val KEY_SPLIT_TUNNEL_MODE = "split_tunnel_mode"
        private const val KEY_SELECTED_APP_PACKAGES = "selected_app_packages"

        const val MODE_PROXY_SELECTED = "PROXY_SELECTED"   // Only selected apps use VPN
        const val MODE_BYPASS_SELECTED = "BYPASS_SELECTED" // All apps use VPN except selected
    }
}
