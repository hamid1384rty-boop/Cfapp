package com.example.data.repository

import com.example.data.model.ProxyConfig
import com.example.data.model.ProxyProtocol
import com.example.vpn.XrayConfigBuilder
import libxray.Libxray
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

/**
 * Real Delay / HTTP URL ping tester modeled after v2rayNG (2dust/v2rayng).
 * Unlike simple TCP connect (which gets fake SYN-ACK responses from DPI/middleboxes in Iran),
 * this performs an end-to-end request through the proxy to an actual endpoint (generate_204 / trace)
 * and verifies that valid HTTP data is actually received.
 */
object RealPingTester {

    /**
     * Measures true end-to-end proxy latency in ms.
     * Returns the elapsed time in ms if the proxy actually completes the handshake and receives
     * a valid HTTP 200/204 response. Returns null if blocked, timed out, or handshake failed.
     */
    suspend fun testRealDelay(
        config: ProxyConfig,
        timeoutMs: Int = 4500
    ): Long? = withContext(Dispatchers.IO) {
        try {
            val json = XrayConfigBuilder.buildTestConfig(config) ?: return@withContext null
            // Runs a temporary Xray-core instance and times an HTTP request through the outbound
            val ms = Libxray.measureDelay(json, "http://cp.cloudflare.com/generate_204", timeoutMs.toLong())
            if (ms >= 0) ms else null
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Fallback TCP socket ping (measures direct TCP handshake time)
     */
    suspend fun testTcpPing(host: String, port: Int, timeoutMs: Int = 2200): Long? =
        withContext(Dispatchers.IO) {
            val cleanHost = host.trim().removePrefix("[").removeSuffix("]")
            if (cleanHost.isBlank() || port <= 0 || port > 65535) return@withContext null
            val socket = Socket()
            try {
                socket.tcpNoDelay = true
                val start = System.currentTimeMillis()
                val socketAddress = InetSocketAddress(cleanHost, port)
                socket.connect(socketAddress, timeoutMs)
                val duration = System.currentTimeMillis() - start
                socket.close()
                duration
            } catch (_: Exception) {
                try { socket.close() } catch (_: Exception) {}
                null
            }
        }
}
