package com.example.data.model

data class LoginRequest(
    val username: String,
    val password: String
)

data class UserProfile(
    val name: String = "",
    val quotaBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val expiresAt: String = ""
) {
    val quotaGB: Double
        get() = if (quotaBytes > 0) quotaBytes.toDouble() / (1024.0 * 1024.0 * 1024.0) else 0.0

    val usedGB: Double
        get() = if (usedBytes > 0) usedBytes.toDouble() / (1024.0 * 1024.0 * 1024.0) else 0.0

    val percentUsed: Int
        get() = if (quotaBytes > 0) ((usedBytes.toDouble() / quotaBytes.toDouble()) * 100).toInt().coerceIn(0, 100) else 0

    val isExpired: Boolean
        get() {
            if (expiresAt.isBlank()) return false
            return try {
                val now = java.time.LocalDate.now().toString()
                expiresAt < now
            } catch (e: Exception) {
                false
            }
        }
}

data class LoginResponse(
    val ok: Boolean,
    val user: UserProfile? = null,
    val subs: List<String> = emptyList(),
    val error: String? = null
)
