package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ProxyConfig
import com.example.data.repository.AppPreferences
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("hamid_taneel", appName)
    }

    @Test
    fun `test sub suffix numbering on proxy config`() {
        val rawVless = "vless://12345678-1234-1234-1234-123456789abc@cf.example.com:443?encryption=none&security=tls&type=ws&host=cf.example.com#Germany"
        val config1 = ProxyConfig.parse(rawVless, subIndex = 1)
        assertNotNull(config1)
        assertEquals("Germany 1", config1!!.name)
        assertEquals(1, config1.subIndex)

        val config2 = ProxyConfig.parse(rawVless, subIndex = 2)
        assertNotNull(config2)
        assertEquals("Germany 2", config2!!.name)
        assertEquals(2, config2.subIndex)

        // Test modifying with clean IP and custom port
        val updated = config1.withCleanIp("104.16.132.229", 8443)
        assertEquals("104.16.132.229", updated.server)
        assertEquals(8443, updated.port)
        assertEquals("cf.example.com", updated.originalServer)
    }

    @Test
    fun `test split tunneling preferences`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = AppPreferences(context)
        prefs.isSplitTunnelingEnabled = true
        prefs.splitTunnelMode = AppPreferences.MODE_PROXY_SELECTED
        prefs.selectedAppPackages = setOf("org.telegram.messenger", "com.instagram.android")

        assertTrue(prefs.isSplitTunnelingEnabled)
        assertEquals(AppPreferences.MODE_PROXY_SELECTED, prefs.splitTunnelMode)
        assertTrue(prefs.selectedAppPackages.contains("org.telegram.messenger"))
        assertTrue(prefs.selectedAppPackages.contains("com.instagram.android"))
    }
}
