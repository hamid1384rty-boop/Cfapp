<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/93461ceb-4b41-4923-a3e6-64389cb81237

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

---

## هسته اتصال: Xray-core

هسته قدیمی (VlessClient / TunPacketRouter) کامل حذف شده و اتصال با **Xray-core** (پوشه `xray-core/`) انجام می‌شود.
اپ کانفیگ را به JSON ایکس‌ری تبدیل می‌کند و اینباند `tun` ایکس‌ری مستقیم روی TUN اندروید کار می‌کند.

قبل از بیلد اپ، باید فایل `app/libs/libxray.aar` ساخته شود (نیاز به Go طبق `xray-core/go.mod` و Android NDK):

    ./build_xray.sh

یا ورک‌فلو گیت‌هاب `.github/workflows/build.yml` را اجرا کنید (AAR و APK را خودش می‌سازد).
