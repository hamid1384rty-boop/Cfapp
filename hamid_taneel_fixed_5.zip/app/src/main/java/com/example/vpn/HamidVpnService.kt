package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.model.ProxyConfig
import com.example.data.model.ProxyProtocol
import com.example.data.repository.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class VpnConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    STOPPING
}

class HamidVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var tunRouter: TunPacketRouter? = null
    private var workerJob: Job? = null
    private var timerJob: Job? = null
    private var usageJob: Job? = null
    private lateinit var prefs: AppPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = AppPreferences(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_DISCONNECT) {
            disconnect()
            return START_NOT_STICKY
        }

        val configName = intent?.getStringExtra(EXTRA_CONFIG_NAME) ?: "hamid_taneel Server"
        val server = intent?.getStringExtra(EXTRA_SERVER) ?: ""
        val port = intent?.getIntExtra(EXTRA_PORT, 443) ?: 443
        val rawUri = intent?.getStringExtra(EXTRA_RAW_URI) ?: ""
        val protocolStr = intent?.getStringExtra(EXTRA_PROTOCOL) ?: "VLESS"
        val originalServer = intent?.getStringExtra(EXTRA_ORIGINAL_SERVER) ?: server

        val protocol = try {
            ProxyProtocol.valueOf(protocolStr)
        } catch (_: Exception) {
            ProxyProtocol.VLESS
        }

        val proxyConfig = if (server.isNotBlank()) {
            ProxyConfig(
                name = configName,
                originalName = configName,
                protocol = protocol,
                server = server,
                port = port,
                originalServer = originalServer,
                originalPort = port,
                subIndex = 1,
                rawUri = rawUri
            )
        } else null

        connect(configName, server, port, proxyConfig)
        return START_STICKY
    }

    private fun safeStartForeground(notification: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (_: Throwable) {}
        }
    }

    private fun connect(
        configName: String,
        server: String,
        port: Int,
        proxyConfig: ProxyConfig?
    ) {
        VpnLog.i("vpn", "شروع اتصال به $configName ($server:$port)")
        _state.value = VpnConnectionState.CONNECTING
        _activeConfigName.value = configName
        safeStartForeground(buildNotification("در حال اتصال به $configName...", false))

        workerJob?.cancel()
        timerJob?.cancel()
        usageJob?.cancel()
        tunRouter?.stop()
        tunRouter = null

        workerJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                delay(200)

                val builder = Builder()
                    .setSession("hamid_taneel: $configName")
                    .addAddress("10.8.0.2", 24)
                    .addRoute("0.0.0.0", 0)
                    .addRoute("198.18.0.0", 15)
                    .addDnsServer("10.8.0.1")
                    .addDnsServer("1.1.1.1")
                    .setMtu(1500)

                // Always disallow this app itself so proxy and DoH traffic don't loop back into TUN
                try {
                    builder.addDisallowedApplication(packageName)
                } catch (_: Throwable) {}

                // Apply Split Tunneling / Per-App Proxy settings
                if (prefs.isSplitTunnelingEnabled) {
                    val selectedPackages = prefs.selectedAppPackages
                    if (prefs.splitTunnelMode == AppPreferences.MODE_PROXY_SELECTED) {
                        // Only selected apps are tunneled through VPN
                        for (pkg in selectedPackages) {
                            try {
                                builder.addAllowedApplication(pkg)
                            } catch (_: Throwable) {}
                        }
                    } else {
                        // All apps are tunneled EXCEPT the selected apps
                        for (pkg in selectedPackages) {
                            try {
                                builder.addDisallowedApplication(pkg)
                            } catch (_: Throwable) {}
                        }
                    }
                }

                val pfd = try {
                    builder.establish()
                } catch (e: Throwable) {
                    null
                }

                if (pfd == null) {
                    VpnLog.e("vpn", "ساخت اینترفیس VPN ناموفق بود (مجوز VPN را چک کن)")
                    _state.value = VpnConnectionState.DISCONNECTED
                    stopSelf()
                    return@launch
                }

                vpnInterface = pfd
                VpnLog.i("vpn", "اینترفیس VPN ساخته شد، TUN فعال است")
                _state.value = VpnConnectionState.CONNECTED
                val startTime = System.currentTimeMillis()
                safeStartForeground(buildNotification("متصل به $configName ($server:$port)", true))

                // Launch real TUN Packet Router with DoH and VLESS client
                val router = TunPacketRouter(
                    vpnService = this@HamidVpnService,
                    pfd = pfd,
                    proxyConfig = proxyConfig,
                    onSpeedUpdate = { downKb, upKb ->
                        _downloadSpeedKb.value = downKb
                        _uploadSpeedKb.value = upKb
                    }
                )
                tunRouter = router
                router.start()

                // Usage reporting: every 10 min, send bytes used since last success through the tunnel.
                // If the worker can't be reached, keep the bytes and retry next round.
                val reportCfg = proxyConfig
                usageJob?.cancel()
                usageJob = CoroutineScope(Dispatchers.IO).launch {
                    var reportedTotal = 0L
                    var failures = 0
                    while (isActive) {
                        delay(USAGE_INTERVAL_MS)
                        val current = tunRouter ?: break
                        if (reportCfg == null || prefs.username.isBlank()) continue
                        val total = current.totalBytes()
                        val delta = total - reportedTotal
                        val st = UsageReporter.report(
                            this@HamidVpnService, reportCfg, prefs.workerUrl,
                            prefs.username, prefs.password, delta
                        )
                        if (st == null) {
                            failures++
                            VpnLog.w("usage", "گزارش مصرف به ورکر نرسید (پشت هم: $failures)")
                            if (failures >= 3) {
                                VpnLog.e("usage", "۳ بار پشت هم گزارش مصرف ناموفق بود، اتصال ادامه دارد و دوباره تلاش میشه")
                            }
                            continue
                        }
                        failures = 0
                        reportedTotal = total
                        VpnLog.i("usage", "گزارش مصرف ثبت شد: ${delta / 1024} KB")
                        if (!st.allowed) {
                            VpnLog.e("usage", "حجم یا زمان اشتراک تمام شده: ${st.reason}")
                            disconnect()
                            break
                        }
                    }
                }

                // Timer loop
                while (isActive) {
                    val duration = (System.currentTimeMillis() - startTime) / 1000
                    _connectionDurationSeconds.value = duration
                    delay(1000)
                }
            } catch (e: Throwable) {
                VpnLog.e("vpn", "خطا در اتصال", e)
                _state.value = VpnConnectionState.DISCONNECTED
                stopSelf()
            }
        }
    }

    private fun disconnect() {
        VpnLog.i("vpn", "قطع اتصال")
        _state.value = VpnConnectionState.STOPPING
        workerJob?.cancel()
        workerJob = null
        timerJob?.cancel()
        timerJob = null
        usageJob?.cancel()
        usageJob = null
        tunRouter?.stop()
        tunRouter = null
        try {
            vpnInterface?.close()
        } catch (_: Throwable) {}
        vpnInterface = null
        _state.value = VpnConnectionState.DISCONNECTED
        _connectionDurationSeconds.value = 0L
        _downloadSpeedKb.value = 0
        _uploadSpeedKb.value = 0
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "hamid_taneel VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "سرویس اتصال شبکه hamid_taneel"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String, isConnected: Boolean): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val disconnectIntent = Intent(this, HamidVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPending = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("hamid_taneel VPN")
            .setContentText(statusText)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (isConnected) {
            builder.addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "قطع اتصال",
                disconnectPending
            )
        }
        return builder.build()
    }

    companion object {
        const val USAGE_INTERVAL_MS = 10L * 60L * 1000L
        const val CHANNEL_ID = "hamid_vpn_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_CONNECT = "com.example.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.example.vpn.DISCONNECT"
        const val EXTRA_CONFIG_NAME = "extra_config_name"
        const val EXTRA_SERVER = "extra_server"
        const val EXTRA_PORT = "extra_port"
        const val EXTRA_RAW_URI = "extra_raw_uri"
        const val EXTRA_PROTOCOL = "extra_protocol"
        const val EXTRA_ORIGINAL_SERVER = "extra_original_server"

        private val _state = MutableStateFlow(VpnConnectionState.DISCONNECTED)
        val state: StateFlow<VpnConnectionState> = _state.asStateFlow()

        private val _activeConfigName = MutableStateFlow<String?>(null)
        val activeConfigName: StateFlow<String?> = _activeConfigName.asStateFlow()

        private val _connectionDurationSeconds = MutableStateFlow(0L)
        val connectionDurationSeconds: StateFlow<Long> = _connectionDurationSeconds.asStateFlow()

        private val _downloadSpeedKb = MutableStateFlow(0)
        val downloadSpeedKb: StateFlow<Int> = _downloadSpeedKb.asStateFlow()

        private val _uploadSpeedKb = MutableStateFlow(0)
        val uploadSpeedKb: StateFlow<Int> = _uploadSpeedKb.asStateFlow()

        fun start(
            context: Context,
            configName: String,
            server: String,
            port: Int,
            rawUri: String = "",
            protocol: String = "VLESS",
            originalServer: String = ""
        ) {
            val intent = Intent(context, HamidVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_CONFIG_NAME, configName)
                putExtra(EXTRA_SERVER, server)
                putExtra(EXTRA_PORT, port)
                putExtra(EXTRA_RAW_URI, rawUri)
                putExtra(EXTRA_PROTOCOL, protocol)
                putExtra(EXTRA_ORIGINAL_SERVER, originalServer)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, HamidVpnService::class.java).apply {
                action = ACTION_DISCONNECT
            }
            context.startService(intent)
        }
    }
}
