package com.example.vpn

import android.net.VpnService
import com.example.data.model.ProxyConfig
import kotlinx.coroutines.runBlocking
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketAddress
import java.util.concurrent.TimeUnit
import javax.net.SocketFactory

/**
 * Sends usage to the account worker (/api/app/usage) THROUGH the user's own config tunnel,
 * not through the phone's normal internet.
 */
object UsageReporter {

    class UsageStatus(val allowed: Boolean, val reason: String, val usedBytes: Long, val quotaBytes: Long)

    /** Sends the bytes used since the last successful report. Returns null if the tunnel/worker failed. */
    fun report(vpn: VpnService, config: ProxyConfig, workerUrl: String, username: String, password: String, bytes: Long): UsageStatus? {
        val base = workerUrl.trim().trimEnd('/')
        if (base.isBlank()) return null
        return try {
            val client = clientFor(vpn, config)
            val body = JSONObject().apply {
                put("username", username)
                put("password", password)
                put("bytes", bytes)
            }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url("$base/api/app/usage").post(body).build()
            client.newCall(request).execute().use { response ->
                val json = JSONObject(response.body?.string() ?: return null)
                if (!json.optBoolean("ok", false)) return null
                UsageStatus(
                    allowed = json.optBoolean("allowed", true),
                    reason = json.optString("reason", ""),
                    usedBytes = json.optLong("usedBytes", 0L),
                    quotaBytes = json.optLong("quotaBytes", 0L)
                )
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun clientFor(vpn: VpnService, config: ProxyConfig): OkHttpClient {
        val factory = object : SocketFactory() {
            override fun createSocket(): Socket = TunnelSocket(vpn, config)
            override fun createSocket(host: String?, port: Int): Socket = TunnelSocket(vpn, config)
            override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket = TunnelSocket(vpn, config)
            override fun createSocket(host: InetAddress?, port: Int): Socket = TunnelSocket(vpn, config)
            override fun createSocket(host: InetAddress?, port: Int, localHost: InetAddress?, localPort: Int): Socket = TunnelSocket(vpn, config)
        }
        return OkHttpClient.Builder()
            .socketFactory(factory)
            // Don't resolve on the phone: the proxy server resolves the hostname itself
            .dns(object : Dns {
                override fun lookup(hostname: String): List<InetAddress> =
                    listOf(InetAddress.getByAddress(hostname, byteArrayOf(0, 0, 0, 0)))
            })
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    /** A java Socket whose bytes travel through a VLESS/Trojan tunnel. TLS is then layered on top by OkHttp. */
    private class TunnelSocket(
        private val vpn: VpnService,
        private val config: ProxyConfig
    ) : Socket() {
        @Volatile private var tunnel: VlessClient.TunnelConnection? = null
        private var connected = false
        private var closed = false

        override fun connect(endpoint: SocketAddress?) = connect(endpoint, 20000)

        override fun connect(endpoint: SocketAddress?, timeout: Int) {
            val isa = endpoint as? InetSocketAddress ?: throw IOException("bad endpoint")
            val host = isa.hostString
            val opened = runBlocking {
                VlessClient.openTunnel(vpn, config, host, isa.port, timeoutMs = if (timeout > 0) timeout else 20000)
            } ?: throw IOException("tunnel to worker failed")
            tunnel = opened
            connected = true
        }

        override fun getInputStream(): InputStream = object : InputStream() {
            override fun read(): Int {
                val one = ByteArray(1)
                val n = read(one, 0, 1)
                return if (n <= 0) -1 else one[0].toInt() and 0xFF
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (len == 0) return 0
                val t = tunnel ?: throw IOException("not connected")
                val buf = ByteArray(len)
                val n = t.readPayload(buf)
                if (n > 0) System.arraycopy(buf, 0, b, off, n)
                return n
            }
        }

        override fun getOutputStream(): OutputStream = object : OutputStream() {
            override fun write(b: Int) {
                write(byteArrayOf(b.toByte()), 0, 1)
            }

            override fun write(b: ByteArray, off: Int, len: Int) {
                val t = tunnel ?: throw IOException("not connected")
                t.writePayload(b.copyOfRange(off, off + len))
            }

            override fun flush() {}
        }

        override fun isConnected(): Boolean = connected
        override fun isClosed(): Boolean = closed

        override fun close() {
            closed = true
            connected = false
            tunnel?.close()
        }
    }
}
