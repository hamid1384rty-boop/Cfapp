package com.example.vpn

import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.example.data.model.ProxyConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

private const val SEQ_MASK = 0xFFFFFFFFL
private const val MAX_TCP_CHUNK = 1360

/**
 * User-space TUN packet router.
 * - Local Fake-DNS on UDP 53
 * - TCP sessions are terminated locally and bridged to the VLESS/Trojan tunnel
 * - Uploads per session go through an ordered queue (single writer), so bytes never get reordered
 */
class TunPacketRouter(
    private val vpnService: VpnService,
    private val pfd: ParcelFileDescriptor,
    private val proxyConfig: ProxyConfig?,
    private val onSpeedUpdate: (downKb: Int, upKb: Int) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    @Volatile private var isRunning = true

    private val inStream = FileInputStream(pfd.fileDescriptor)
    private val outStream = FileOutputStream(pfd.fileDescriptor)

    // Virtual Fake-DNS pool: 198.18.0.2 to 198.18.254.254 (RFC 2544 benchmark pool)
    private val nextIpCounter = AtomicInteger(2)
    private val fakeIpToDomain = ConcurrentHashMap<String, String>()
    private val domainToFakeIp = ConcurrentHashMap<String, String>()

    // Active TCP sessions
    private val tcpSessions = ConcurrentHashMap<String, TcpSession>()

    // Traffic statistics
    private val bytesDownloaded = AtomicLong(0)
    private val bytesUploaded = AtomicLong(0)

    class TcpSession(
        val key: String,
        val srcIp: String,
        val srcPort: Int,
        val dstIp: String,
        val dstPort: Int,
        @Volatile var mySeq: Long,
        @Volatile var expectedClientSeq: Long
    ) {
        @Volatile var tunnel: VlessClient.TunnelConnection? = null
        @Volatile var isClosed = false
        @Volatile var clientFinished = false
        var readerJob: Job? = null
        var targetHost: String? = null
        // Single producer (packet reader thread) -> single consumer (session writer). Order is preserved.
        val uploadQueue = Channel<ByteArray>(Channel.UNLIMITED)
    }

    /** Total payload bytes that went through the tunnel (up + down). */
    fun totalBytes(): Long = bytesDownloaded.get() + bytesUploaded.get()

    fun start() {
        // 1. Packet Reader Loop
        scope.launch {
            readLoop()
        }

        // 2. Speed stats reporter loop (every 1 second)
        scope.launch {
            var lastDown = 0L
            var lastUp = 0L
            while (isActive && isRunning) {
                delay(1000)
                val currentDown = bytesDownloaded.get()
                val currentUp = bytesUploaded.get()
                val downRateKb = ((currentDown - lastDown) / 1024).toInt()
                val upRateKb = ((currentUp - lastUp) / 1024).toInt()
                lastDown = currentDown
                lastUp = currentUp
                onSpeedUpdate(Math.max(0, downRateKb), Math.max(0, upRateKb))
            }
        }
    }

    private suspend fun readLoop() = withContext(Dispatchers.IO) {
        val buffer = ByteArray(4096)
        while (isActive && isRunning) {
            val bytesRead = try {
                inStream.read(buffer)
            } catch (_: Throwable) {
                -1
            }
            if (bytesRead <= 0) break

            val ipPacket = PacketUtils.parseIp(buffer, bytesRead) ?: continue
            when (ipPacket.protocol) {
                PacketUtils.PROTOCOL_UDP -> handleUdpPacket(buffer, ipPacket)
                PacketUtils.PROTOCOL_TCP -> handleTcpPacket(buffer, ipPacket)
            }
        }
    }

    private fun handleUdpPacket(buffer: ByteArray, ipPacket: PacketUtils.ParsedIpPacket) {
        val udpPacket = PacketUtils.parseUdp(buffer, ipPacket) ?: return

        // Intercept DNS queries (UDP Port 53)
        if (udpPacket.dstPort == 53 && udpPacket.payloadLength > 0) {
            val dnsPayload = buffer.copyOfRange(udpPacket.payloadOffset, udpPacket.payloadOffset + udpPacket.payloadLength)
            handleDnsQuery(ipPacket.srcIp, udpPacket.srcPort, ipPacket.dstIp, dnsPayload)
        }
    }

    /**
     * Responds to DNS queries locally via Fake-DNS without external delays or poisoning.
     */
    private fun handleDnsQuery(
        clientIp: String,
        clientPort: Int,
        destDnsServer: String,
        dnsQueryBytes: ByteArray
    ) {
        try {
            val qname = PacketUtils.extractDnsQueryDomain(dnsQueryBytes)
            val qtype = PacketUtils.extractDnsQueryType(dnsQueryBytes)

            val replyData = if (qtype == 28) {
                // AAAA (IPv6): empty answer so apps connect via IPv4
                PacketUtils.buildDnsEmptyResponse(dnsQueryBytes)
            } else if (!qname.isNullOrBlank()) {
                // Type A (IPv4): allocate/fetch virtual IP from 198.18.x.x pool
                val fakeIp = domainToFakeIp.getOrPut(qname) {
                    val count = nextIpCounter.getAndIncrement()
                    val b3 = (count shr 8) and 0xFF
                    val b4 = count and 0xFF
                    val ip = "198.18.$b3.$b4"
                    fakeIpToDomain[ip] = qname
                    ip
                }

                val ipBytes = fakeIp.split(".").map { it.toInt().toByte() }.toByteArray()
                PacketUtils.buildDnsResponse(dnsQueryBytes, ipBytes)
            } else {
                PacketUtils.buildDnsEmptyResponse(dnsQueryBytes)
            }

            val replyPacket = PacketUtils.buildUdpPacket(
                srcIp = destDnsServer,
                dstIp = clientIp,
                srcPort = 53,
                dstPort = clientPort,
                payload = replyData
            )
            writeToTun(replyPacket)
        } catch (_: Throwable) {}
    }

    private fun handleTcpPacket(buffer: ByteArray, ipPacket: PacketUtils.ParsedIpPacket) {
        val tcpPacket = PacketUtils.parseTcp(buffer, ipPacket) ?: return
        val sessionKey = "${ipPacket.srcIp}:${tcpPacket.srcPort}->${ipPacket.dstIp}:${tcpPacket.dstPort}"

        // 1. SYN: client wants to connect
        if (tcpPacket.isSyn && !tcpPacket.isAck) {
            val existing = tcpSessions[sessionKey]
            if (existing != null && !existing.isClosed) return // retransmitted SYN, already answered

            val startSeq = Random.nextInt(100000, 900000).toLong()
            val session = TcpSession(
                key = sessionKey,
                srcIp = ipPacket.srcIp,
                srcPort = tcpPacket.srcPort,
                dstIp = ipPacket.dstIp,
                dstPort = tcpPacket.dstPort,
                mySeq = (startSeq + 1) and SEQ_MASK,
                expectedClientSeq = (tcpPacket.seq + 1) and SEQ_MASK
            )

            // Resolve target host from Fake-DNS if available
            session.targetHost = fakeIpToDomain[ipPacket.dstIp] ?: ipPacket.dstIp
            tcpSessions[sessionKey] = session

            // SYN + ACK back to TUN with MSS option (1400)
            val synAck = PacketUtils.buildTcpPacket(
                srcIp = ipPacket.dstIp,
                dstIp = ipPacket.srcIp,
                srcPort = tcpPacket.dstPort,
                dstPort = tcpPacket.srcPort,
                seq = startSeq,
                ack = session.expectedClientSeq,
                flags = PacketUtils.TCP_FLAG_SYN or PacketUtils.TCP_FLAG_ACK,
                window = 65535,
                includeMssOption = true
            )
            writeToTun(synAck)

            scope.launch(Dispatchers.IO) { runSession(session) }
            return
        }

        val session = tcpSessions[sessionKey] ?: return
        if (session.isClosed) return

        // 2. RST: clean up immediately
        if (tcpPacket.isRst) {
            closeSession(session)
            return
        }

        // 3. FIN: client finished sending. Ack it, but keep the downlink open until the remote closes.
        if (tcpPacket.isFin) {
            if (!session.clientFinished) {
                session.expectedClientSeq = (tcpPacket.seq + 1) and SEQ_MASK
                session.clientFinished = true
                session.uploadQueue.close()
            }
            sendAck(session, ipPacket, tcpPacket)
            return
        }

        // 4. Data from client
        if (tcpPacket.payloadLength > 0 && !session.clientFinished) {
            var off = tcpPacket.payloadOffset
            var len = tcpPacket.payloadLength
            val expected = session.expectedClientSeq
            val distance = (tcpPacket.seq - expected) and SEQ_MASK

            if (distance != 0L) {
                if (distance < 0x80000000L) {
                    // Segment from the future (gap). We don't reassemble; re-ack what we have so the client resends.
                    sendAck(session, ipPacket, tcpPacket)
                    return
                }
                // Retransmitted bytes we already have. Keep only the new tail.
                val overlap = (expected - tcpPacket.seq) and SEQ_MASK
                if (overlap >= len) {
                    sendAck(session, ipPacket, tcpPacket)
                    return
                }
                off += overlap.toInt()
                len -= overlap.toInt()
            }

            val payload = buffer.copyOfRange(off, off + len)
            session.expectedClientSeq = (expected + len) and SEQ_MASK
            bytesUploaded.addAndGet(payload.size.toLong())

            // Inspect SNI / Host only until the tunnel is up (first bytes decide the target)
            if (session.tunnel == null) {
                if (session.dstPort == 443) {
                    val sni = PacketUtils.extractSniFromTlsClientHello(payload)
                    if (!sni.isNullOrBlank()) session.targetHost = sni
                } else if (session.dstPort == 80) {
                    val host = PacketUtils.extractHostFromHttpRequest(payload)
                    if (!host.isNullOrBlank()) session.targetHost = host
                }
            }

            sendAck(session, ipPacket, tcpPacket)
            session.uploadQueue.trySend(payload)
        }
    }

    private fun sendAck(session: TcpSession, ipPacket: PacketUtils.ParsedIpPacket, tcpPacket: PacketUtils.ParsedTcpPacket) {
        val ackPacket = PacketUtils.buildTcpPacket(
            srcIp = ipPacket.dstIp,
            dstIp = ipPacket.srcIp,
            srcPort = tcpPacket.dstPort,
            dstPort = tcpPacket.srcPort,
            seq = session.mySeq,
            ack = session.expectedClientSeq,
            flags = PacketUtils.TCP_FLAG_ACK
        )
        writeToTun(ackPacket)
    }

    /**
     * One coroutine per session: open the tunnel with the first payload, then write queued uploads in order.
     * The downlink reader is started once the tunnel is up.
     */
    private suspend fun runSession(session: TcpSession) {
        val first = session.uploadQueue.receiveCatching().getOrNull()
        if (first == null) {
            // Client closed before sending anything: finish our side too
            if (!session.isClosed && session.clientFinished) {
                writeToTun(PacketUtils.buildTcpPacket(
                    srcIp = session.dstIp,
                    dstIp = session.srcIp,
                    srcPort = session.dstPort,
                    dstPort = session.srcPort,
                    seq = session.mySeq,
                    ack = session.expectedClientSeq,
                    flags = PacketUtils.TCP_FLAG_FIN or PacketUtils.TCP_FLAG_ACK
                ))
                session.mySeq = (session.mySeq + 1) and SEQ_MASK
            }
            closeSession(session)
            return
        }

        val targetHost = session.targetHost ?: fakeIpToDomain[session.dstIp] ?: session.dstIp
        val tunnel = VlessClient.openTunnel(
            vpnService = vpnService,
            config = proxyConfig,
            targetHost = targetHost,
            targetPort = session.dstPort,
            initialPayload = first
        )

        if (tunnel == null) {
            val rstPacket = PacketUtils.buildTcpPacket(
                srcIp = session.dstIp,
                dstIp = session.srcIp,
                srcPort = session.dstPort,
                dstPort = session.srcPort,
                seq = session.mySeq,
                ack = session.expectedClientSeq,
                flags = PacketUtils.TCP_FLAG_RST
            )
            writeToTun(rstPacket)
            closeSession(session)
            return
        }

        if (session.isClosed) {
            tunnel.close()
            return
        }

        session.tunnel = tunnel
        session.readerJob = scope.launch(Dispatchers.IO) {
            downlink(session, tunnel)
        }

        try {
            for (payload in session.uploadQueue) {
                tunnel.writePayload(payload)
            }
        } catch (_: Throwable) {
            closeSession(session)
        }
    }

    /** Tunnel -> TUN, chunked to MSS. */
    private suspend fun downlink(session: TcpSession, tunnel: VlessClient.TunnelConnection) {
        val streamBuf = ByteArray(8192)
        while (currentCoroutineContext().isActive && isRunning && !session.isClosed) {
            val n = try {
                tunnel.readPayload(streamBuf)
            } catch (_: Throwable) {
                -1
            }
            if (n < 0) break
            if (n == 0) continue

            var offset = 0
            while (offset < n && !session.isClosed) {
                val chunkLen = Math.min(MAX_TCP_CHUNK, n - offset)
                val chunk = streamBuf.copyOfRange(offset, offset + chunkLen)

                val dataPacket = PacketUtils.buildTcpPacket(
                    srcIp = session.dstIp,
                    dstIp = session.srcIp,
                    srcPort = session.dstPort,
                    dstPort = session.srcPort,
                    seq = session.mySeq,
                    ack = session.expectedClientSeq,
                    flags = PacketUtils.TCP_FLAG_PSH or PacketUtils.TCP_FLAG_ACK,
                    payload = chunk
                )
                session.mySeq = (session.mySeq + chunkLen) and SEQ_MASK
                writeToTun(dataPacket)
                bytesDownloaded.addAndGet(chunkLen.toLong())
                offset += chunkLen
            }
        }

        // Remote finished: send FIN + ACK, then tear down
        if (!session.isClosed) {
            val finPacket = PacketUtils.buildTcpPacket(
                srcIp = session.dstIp,
                dstIp = session.srcIp,
                srcPort = session.dstPort,
                dstPort = session.srcPort,
                seq = session.mySeq,
                ack = session.expectedClientSeq,
                flags = PacketUtils.TCP_FLAG_FIN or PacketUtils.TCP_FLAG_ACK
            )
            session.mySeq = (session.mySeq + 1) and SEQ_MASK
            writeToTun(finPacket)
            closeSession(session)
        }
    }

    private fun closeSession(session: TcpSession) {
        if (session.isClosed) return
        session.isClosed = true
        session.uploadQueue.close()
        session.readerJob?.cancel()
        try {
            session.tunnel?.close()
        } catch (_: Throwable) {}
        tcpSessions.remove(session.key, session)
    }

    private fun writeToTun(packetBytes: ByteArray) {
        synchronized(outStream) {
            try {
                outStream.write(packetBytes)
                outStream.flush()
            } catch (_: Throwable) {}
        }
    }

    fun stop() {
        isRunning = false
        for (session in tcpSessions.values) {
            session.isClosed = true
            session.uploadQueue.close()
            session.readerJob?.cancel()
            try {
                session.tunnel?.close()
            } catch (_: Throwable) {}
        }
        tcpSessions.clear()
        scope.cancel()
        try {
            inStream.close()
        } catch (_: Throwable) {}
        try {
            outStream.close()
        } catch (_: Throwable) {}
    }
}
